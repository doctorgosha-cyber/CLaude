#!/usr/bin/env python3
"""Run the 5 fixed tasks in fresh headless Claude Code sessions and record metrics.
usage: run_arm.py <arm> <repo_dir> <out_dir> [--tasks abcde] [--trial N] [--extra '<extra claude args>']
"""
import json, os, shlex, subprocess, sys, time, uuid, argparse, shutil

TASKS = {
    "a": "Where is the GLTFLoader's handling of KHR_materials_transmission, and which function applies it?",
    "b": "List every file that imports BufferGeometryUtils.",
    "c": "Explain how WebGLRenderer decides the shadow map type.",
    "d": "Find the code path that disposes textures when a material is disposed.",
    "e": "Add a one-line comment above the main export of src/core/Object3D.js (do not commit).",
}
ALLOWED = "Bash,Read,Grep,Glob,Edit,Write,MultiEdit"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("arm"); ap.add_argument("repo"); ap.add_argument("out")
    ap.add_argument("--tasks", default="abcde"); ap.add_argument("--trial", type=int, default=1)
    ap.add_argument("--extra", default=""); ap.add_argument("--warmup", action="store_true")
    ap.add_argument("--allowed", default=ALLOWED)
    a = ap.parse_args()
    out = os.path.join(a.out, f"{a.arm}-t{a.trial}"); os.makedirs(out, exist_ok=True)
    harness = os.path.dirname(os.path.abspath(__file__))
    env = dict(os.environ)
    env.pop("CLAUDE_CODE_SESSION_ID", None)
    env["DO_NOT_TRACK"] = "1"
    env["NODE_OPTIONS"] = f"--require {os.path.join(harness, 'netlog.cjs')}"
    env["NETLOG_FILE"] = os.path.join(out, "netlog.txt")
    extra = shlex.split(a.extra) if a.extra else []

    def run(prompt, sid, log_path):
        cmd = ["claude", "-p", prompt, "--model", "sonnet", "--output-format", "stream-json", "--verbose",
               "--permission-mode", "acceptEdits", "--allowedTools", a.allowed, "--session-id", sid] + extra
        t0 = time.time()
        with open(log_path, "w") as lf, open(log_path + ".stderr", "w") as ef:
            p = subprocess.run(cmd, cwd=a.repo, env=env, stdin=subprocess.DEVNULL, stdout=lf, stderr=ef, timeout=1500)
        return time.time() - t0, p.returncode, cmd

    if a.warmup:
        sid = str(uuid.uuid4())
        wt, rc, _ = run("Reply with exactly the word OK and nothing else.", sid, os.path.join(out, "warmup.jsonl"))
        print(f"[{a.arm}] warmup rc={rc} {wt:.1f}s", flush=True)

    summary = {}
    for t in a.tasks:
        prompt = TASKS[t]; sid = str(uuid.uuid4())
        log_path = os.path.join(out, f"{t}.jsonl")
        wall, rc, cmd = run(prompt, sid, log_path)
        m = parse(log_path)
        m.update({"task": t, "prompt": prompt, "session_id": sid, "wall_s": round(wall, 1), "rc": rc, "cmd": cmd})
        if t == "e":
            diff = subprocess.run(["git", "diff", "--", "src/core/Object3D.js"], cwd=a.repo, capture_output=True, text=True).stdout
            status = subprocess.run(["git", "status", "--short"], cwd=a.repo, capture_output=True, text=True).stdout
            open(os.path.join(out, "e.diff"), "w").write(diff)
            m["e_diff_lines"] = diff.count("\n"); m["git_status_after"] = status
            subprocess.run(["git", "checkout", "--", "src/core/Object3D.js"], cwd=a.repo)
        json.dump(m, open(os.path.join(out, f"{t}.json"), "w"), indent=2)
        open(os.path.join(out, f"{t}.answer.md"), "w").write(m.get("result_text") or "")
        summary[t] = {k: m.get(k) for k in ("total_tokens", "input_total", "output_tokens", "tool_calls", "api_calls", "num_turns", "wall_s", "duration_ms", "cost_usd", "rc", "is_error")}
        print(f"[{a.arm} t{a.trial}] task {t}: {summary[t]}", flush=True)
    json.dump(summary, open(os.path.join(out, "summary.json"), "w"), indent=2)

def parse(path):
    m = {"tool_calls": 0, "tools": {}, "api_calls": 0, "result_text": None, "is_error": None}
    init = None
    for line in open(path):
        line = line.strip()
        if not line: continue
        try: ev = json.loads(line)
        except Exception: continue
        ty = ev.get("type")
        if ty == "system" and ev.get("subtype") == "init":
            init = ev
            m["init_mcp_servers"] = ev.get("mcp_servers"); m["init_model"] = ev.get("model")
            m["init_tools_n"] = len(ev.get("tools") or []); m["init_mcp_tools"] = [x for x in (ev.get("tools") or []) if x.startswith("mcp__")]
        elif ty == "assistant":
            msg = ev.get("message", {})
            content = msg.get("content", [])
            # one assistant event per API response (text and tool_use blocks may be split into several events sharing message id)
            mid = msg.get("id")
            m.setdefault("_ids", set()).add(mid)
            for b in content:
                if b.get("type") == "tool_use":
                    m["tool_calls"] += 1
                    m["tools"][b.get("name")] = m["tools"].get(b.get("name"), 0) + 1
        elif ty == "result":
            u = ev.get("usage", {})
            m["usage"] = u
            m["input_fresh"] = u.get("input_tokens", 0)
            m["cache_create"] = u.get("cache_creation_input_tokens", 0)
            m["cache_read"] = u.get("cache_read_input_tokens", 0)
            m["input_total"] = m["input_fresh"] + m["cache_create"] + m["cache_read"]
            m["output_tokens"] = u.get("output_tokens", 0)
            m["total_tokens"] = m["input_total"] + m["output_tokens"]
            m["cost_usd"] = ev.get("total_cost_usd"); m["duration_ms"] = ev.get("duration_ms"); m["duration_api_ms"] = ev.get("duration_api_ms")
            m["num_turns"] = ev.get("num_turns"); m["result_text"] = ev.get("result"); m["is_error"] = ev.get("is_error")
            m["model_usage"] = ev.get("modelUsage"); m["permission_denials"] = ev.get("permission_denials")
    m["api_calls"] = len(m.pop("_ids", set()))
    return m

if __name__ == "__main__":
    main()
