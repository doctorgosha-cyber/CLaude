#!/usr/bin/env python3
"""Build the per-task A vs B comparison table from results/<arm>-t<N>/<task>.json."""
import json, os, sys, glob
R = sys.argv[1]
trials = sorted({os.path.basename(d).split("-t")[1] for d in glob.glob(os.path.join(R, "*-t*")) if os.path.isdir(d)})
def load(arm, trial, t):
    p = os.path.join(R, f"{arm}-t{trial}", f"{t}.json")
    return json.load(open(p)) if os.path.exists(p) else None
def pct(a, b):
    return "n/a" if not a else f"{(b - a) / a * 100:+.0f}%"
out = []
for trial in trials:
    out.append(f"\n### Trial {trial}\n")
    out.append("| Task | A tokens (in+out) | B tokens (in+out) | Δ tokens | A tool calls | B tool calls | A time s | B time s | Δ time | A API calls | B API calls | A cost $ | B cost $ |")
    out.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    tot = {"A": [0,0,0,0.0,0], "B": [0,0,0,0.0,0]}
    for t in "abcde":
        a, b = load("A", trial, t), load("B", trial, t)
        if not a or not b: continue
        for arm, m in (("A", a), ("B", b)):
            tot[arm][0] += m["total_tokens"]; tot[arm][1] += m["tool_calls"]; tot[arm][2] += m["api_calls"]; tot[arm][3] += m["wall_s"]; tot[arm][4] += m["cost_usd"] or 0
        out.append(f"| ({t}) | {a['total_tokens']:,} | {b['total_tokens']:,} | {pct(a['total_tokens'], b['total_tokens'])} | {a['tool_calls']} | {b['tool_calls']} | {a['wall_s']} | {b['wall_s']} | {pct(a['wall_s'], b['wall_s'])} | {a['api_calls']} | {b['api_calls']} | {a['cost_usd']:.3f} | {b['cost_usd']:.3f} |")
    A, B = tot["A"], tot["B"]
    out.append(f"| **Total** | **{A[0]:,}** | **{B[0]:,}** | **{pct(A[0], B[0])}** | **{A[1]}** | **{B[1]}** | **{A[3]:.1f}** | **{B[3]:.1f}** | **{pct(A[3], B[3])}** | {A[2]} | {B[2]} | {A[4]:.3f} | {B[4]:.3f} |")
    # token breakdown
    out.append("\nToken breakdown (fresh input / cache write / cache read / output):\n")
    out.append("| Task | A fresh | A cache-write | A cache-read | A out | B fresh | B cache-write | B cache-read | B out |")
    out.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")
    for t in "abcde":
        a, b = load("A", trial, t), load("B", trial, t)
        if not a or not b: continue
        out.append(f"| ({t}) | {a['input_fresh']:,} | {a['cache_create']:,} | {a['cache_read']:,} | {a['output_tokens']:,} | {b['input_fresh']:,} | {b['cache_create']:,} | {b['cache_read']:,} | {b['output_tokens']:,} |")
    out.append("\nTools used per task:\n")
    for t in "abcde":
        a, b = load("A", trial, t), load("B", trial, t)
        if not a or not b: continue
        out.append(f"- ({t}) A: {a['tools']} | B: {b['tools']}")
print("\n".join(out))
