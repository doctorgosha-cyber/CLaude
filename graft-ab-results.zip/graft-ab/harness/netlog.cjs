// Log-only preload: records every outbound host any Node process contacts.
// Activated via NODE_OPTIONS=--require. Never throws, never blocks.
try {
  const fs = require('fs');
  const path = require('path');
  const LOG = process.env.NETLOG_FILE;
  if (LOG) {
    const tag = () => `${new Date().toISOString()} pid=${process.pid} argv=${path.basename(process.argv[1] || process.argv[0] || '?')}`;
    const write = (kind, target) => { try { fs.appendFileSync(LOG, `${tag()} ${kind} ${target}\n`); } catch {} };
    const hostOf = (input) => { try { const u = typeof input === 'string' ? input : (input && input.url) || String(input); return new URL(u).host; } catch { return String(input).slice(0, 120); } };
    if (typeof globalThis.fetch === 'function') {
      const orig = globalThis.fetch;
      globalThis.fetch = function (input, init) { write('fetch', hostOf(input)); return orig.apply(this, arguments); };
    }
    for (const modName of ['http', 'https']) {
      const m = require(modName);
      for (const fn of ['request', 'get']) {
        const orig = m[fn];
        m[fn] = function (a, b) {
          try { let h = typeof a === 'string' ? hostOf(a) : (a && (a.host || a.hostname)) || (b && (b.host || b.hostname)) || '?'; write(modName + '.' + fn, String(h)); } catch {}
          return orig.apply(this, arguments);
        };
      }
    }
    const net = require('net');
    const origConnect = net.Socket.prototype.connect;
    net.Socket.prototype.connect = function (...args) {
      try { const o = args[0]; if (o && typeof o === 'object' && (o.host || o.port)) write('net.connect', `${o.host || ''}:${o.port || ''}`); else if (typeof args[0] === 'number') write('net.connect', `${args[1] || ''}:${args[0]}`); } catch {}
      return origConnect.apply(this, args);
    };
  }
} catch {}
