# src/audio/PositionalAudio.js

- PositionalAudio · class · L40-L251 — class PositionalAudio extends Audio
- constructor · method · L47-L62 — constructor( listener )
- connect · method · L64-L72 — connect()
- disconnect · method · L74-L82 — disconnect()
- getOutput · method · L84-L88 — getOutput()
- getRefDistance · method · L95-L99 — getRefDistance()
- setRefDistance · method · L109-L115 — setRefDistance( value )
- getRolloffFactor · method · L122-L126 — getRolloffFactor()
- setRolloffFactor · method · L134-L140 — setRolloffFactor( value )
- getDistanceModel · method · L147-L151 — getDistanceModel()
- setDistanceModel · method · L163-L169 — setDistanceModel( value )
- getMaxDistance · method · L176-L180 — getMaxDistance()
- setMaxDistance · method · L191-L197 — setMaxDistance( value )
- setDirectionalCone · method · L207-L215 — setDirectionalCone( coneInnerAngle, coneOuterAngle, coneOuterGain )
- updateMatrixWorld · method · L217-L249 — updateMatrixWorld( force )
