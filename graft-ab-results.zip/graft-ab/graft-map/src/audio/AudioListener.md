# src/audio/AudioListener.js

- AudioListener · class · L24-L214 — class AudioListener extends Object3D
- constructor · method · L29-L76 — constructor()
- getInput · method · L85-L89 — getInput()
- removeFilter · method · L96-L109 — removeFilter()
- getFilter · method · L116-L120 — getFilter()
- setFilter · method · L128-L147 — setFilter( value )
- getMasterVolume · method · L154-L158 — getMasterVolume()
- setMasterVolume · method · L167-L173 — setMasterVolume( value )
- updateMatrixWorld · method · L175-L212 — updateMatrixWorld( force )
