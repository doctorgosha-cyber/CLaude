# src/audio/AudioContext.js

- AudioContext · class · L8-L38 — class AudioContext
- getContext · method · L15-L25 — static getContext()
- setContext · method · L32-L36 — static setContext( value )
