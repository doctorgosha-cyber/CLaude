# src/audio/AudioAnalyser.js

- AudioAnalyser · class · L28-L95 — class AudioAnalyser
- constructor · method · L36-L55 — constructor( audio, fftSize = 2048 )
- getFrequencyData · method · L67-L73 — getFrequencyData()
- getAverageFrequency · method · L80-L93 — getAverageFrequency()
