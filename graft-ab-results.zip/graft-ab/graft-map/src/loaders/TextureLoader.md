# src/loaders/TextureLoader.js

- TextureLoader · class · L21-L71 — class TextureLoader extends Loader
- constructor · method · L28-L32 — constructor( manager )
- load · method · L46-L69 — load( url, onLoad, onProgress, onError )
