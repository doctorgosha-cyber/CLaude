# src/loaders/CubeTextureLoader.js

- CubeTextureLoader · class · L32-L100 — class CubeTextureLoader extends Loader
- constructor · method · L39-L43 — constructor( manager )
- load · method · L59-L98 — load( urls, onLoad, onProgress, onError )
- loadTexture · function · L70-L88 — function loadTexture( i )
