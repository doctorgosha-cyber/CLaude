# src/loaders/DataTextureLoader.js

- DataTextureLoader · class · L16-L149 — class DataTextureLoader extends Loader
- constructor · method · L23-L27 — constructor( manager )
- load · method · L41-L147 — load( url, onLoad, onProgress, onError )
