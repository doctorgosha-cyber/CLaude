# src/loaders/AnimationLoader.js

- AnimationLoader · class · L16-L94 — class AnimationLoader extends Loader
- constructor · method · L23-L27 — constructor( manager )
- load · method · L38-L70 — load( url, onLoad, onProgress, onError )
- parse · method · L78-L92 — parse( json )
