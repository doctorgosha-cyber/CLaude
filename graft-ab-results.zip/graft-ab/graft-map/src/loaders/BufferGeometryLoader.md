# src/loaders/BufferGeometryLoader.js

- BufferGeometryLoader · class · L27-L240 — class BufferGeometryLoader extends Loader
- constructor · method · L34-L38 — constructor( manager )
- load · method · L48-L80 — load( url, onLoad, onProgress, onError )
- parse · method · L88-L238 — parse( json )
- getInterleavedBuffer · function · L93-L110 — function getInterleavedBuffer( json, uuid )
- getArrayBuffer · function · L112-L125 — function getArrayBuffer( json, uuid )
