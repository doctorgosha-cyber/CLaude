# src/loaders/AudioLoader.js

- AudioLoader · class · L22-L94 — class AudioLoader extends Loader
- constructor · method · L29-L33 — constructor( manager )
- load · method · L44-L92 — load( url, onLoad, onProgress, onError )
- handleError · function · L76-L90 — function handleError( e )
