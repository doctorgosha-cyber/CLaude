# src/loaders/LoaderUtils.js

- LoaderUtils · class · L4-L57 — class LoaderUtils
- extractUrlBase · method · L12-L20 — static extractUrlBase( url )
- resolveURL · method · L31-L55 — static resolveURL( url, path )
