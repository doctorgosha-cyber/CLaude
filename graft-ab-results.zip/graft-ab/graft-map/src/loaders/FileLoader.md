# src/loaders/FileLoader.js

- HttpError · class · L6-L15 — class HttpError extends Error
- constructor · method · L8-L13 — constructor( message, response )
- FileLoader · class · L32-L364 — class FileLoader extends Loader
- constructor · method · L39-L67 — constructor( manager )
- load · method · L78-L322 — load( url, onLoad, onProgress, onError )
- start · method · L175-L212 — start( controller )
- readData · function · L179-L210 — function readData()
- setResponseType · method · L330-L335 — setResponseType( value )
- setMimeType · method · L343-L348 — setMimeType( value )
- abort · method · L355-L362 — abort()
