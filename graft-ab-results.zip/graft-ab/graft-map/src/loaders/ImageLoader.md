# src/loaders/ImageLoader.js

- ImageLoader · class · L20-L165 — class ImageLoader extends Loader
- constructor · method · L27-L31 — constructor( manager )
- load · method · L45-L163 — load( url, onLoad, onProgress, onError )
- onImageLoad · function · L90-L111 — function onImageLoad()
- onImageError · function · L113-L138 — function onImageError( event )
- removeEventListeners · function · L140-L145 — function removeEventListeners()
