# src/loaders/CompressedTextureLoader.js

- CompressedTextureLoader · class · L16-L152 — class CompressedTextureLoader extends Loader
- constructor · method · L23-L27 — constructor( manager )
- load · method · L41-L150 — load( url, onLoad, onProgress, onError )
- loadTexture · function · L57-L86 — function loadTexture( i )
