# src/loaders/Loader.js

- Loader · class · L8-L188 — class Loader
- constructor · method · L15-L64 — constructor( manager )
- load · method · L76-L76 — load( /* url, onLoad, onProgress, onError */ )
- loadAsync · method · L85-L95 — loadAsync( url, onProgress )
- parse · method · L104-L104 — parse( /* data */ )
- setCrossOrigin · method · L113-L118 — setCrossOrigin( crossOrigin )
- setWithCredentials · method · L129-L134 — setWithCredentials( value )
- setPath · method · L142-L147 — setPath( path )
- setResourcePath · method · L155-L160 — setResourcePath( resourcePath )
- setRequestHeader · method · L169-L174 — setRequestHeader( requestHeader )
- abort · method · L182-L186 — abort()
