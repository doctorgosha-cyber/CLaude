# src/loaders/ImageBitmapLoader.js

- ImageBitmapLoader · class · L29-L217 — class ImageBitmapLoader extends Loader
- constructor · method · L36-L77 — constructor( manager )
- setOptions · method · L86-L92 — setOptions( options )
- load · method · L103-L201 — load( url, onLoad, onProgress, onError )
- abort · method · L208-L215 — abort()
