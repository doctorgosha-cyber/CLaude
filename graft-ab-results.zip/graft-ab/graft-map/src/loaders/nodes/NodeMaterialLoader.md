# src/loaders/nodes/NodeMaterialLoader.js

- NodeMaterialLoader · class · L8-L106 — class NodeMaterialLoader extends MaterialLoader
- constructor · method · L15-L33 — constructor( manager )
- parse · method · L41-L58 — parse( json )
- setNodes · method · L66-L71 — setNodes( value )
- setNodeMaterials · method · L79-L84 — setNodeMaterials( value )
- createMaterialFromType · method · L92-L104 — createMaterialFromType( type )
