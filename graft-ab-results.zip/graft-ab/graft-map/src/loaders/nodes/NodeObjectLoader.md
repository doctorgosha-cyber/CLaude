# src/loaders/nodes/NodeObjectLoader.js

- NodeObjectLoader · class · L12-L149 — class NodeObjectLoader extends ObjectLoader
- constructor · method · L19-L45 — constructor( manager )
- setNodes · method · L53-L58 — setNodes( value )
- setNodeMaterials · method · L66-L71 — setNodeMaterials( value )
- parse · method · L80-L90 — parse( json, onLoad )
- parseNodes · method · L99-L113 — parseNodes( json, textures )
- parseMaterials · method · L122-L147 — parseMaterials( json, textures )
