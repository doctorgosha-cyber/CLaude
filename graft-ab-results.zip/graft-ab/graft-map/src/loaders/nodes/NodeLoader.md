# src/loaders/nodes/NodeLoader.js

- NodeLoader · class · L11-L191 — class NodeLoader extends Loader
- constructor · method · L18-L36 — constructor( manager )
- load · method · L46-L76 — load( url, onLoad, onProgress, onError )
- parseNodes · method · L84-L116 — parseNodes( json )
- parse · method · L128-L144 — parse( json )
- setTextures · method · L152-L157 — setTextures( value )
- setNodes · method · L165-L170 — setNodes( value )
- createNodeFromType · method · L178-L189 — createNodeFromType( type )
