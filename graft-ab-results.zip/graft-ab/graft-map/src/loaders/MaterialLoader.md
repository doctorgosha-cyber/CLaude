# src/loaders/MaterialLoader.js

- MaterialLoader · class · L42-L435 — class MaterialLoader extends Loader
- constructor · method · L49-L60 — constructor( manager )
- load · method · L70-L102 — load( url, onLoad, onProgress, onError )
- parse · method · L110-L373 — parse( json )
- getTexture · function · L114-L124 — function getTexture( name )
- setTextures · method · L382-L387 — setTextures( value )
- createMaterialFromType · method · L395-L399 — createMaterialFromType( type )
- createMaterialFromType · method · L408-L433 — static createMaterialFromType( type )
