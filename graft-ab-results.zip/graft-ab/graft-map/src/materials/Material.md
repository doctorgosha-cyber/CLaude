# src/materials/Material.js

- Material · class · L16-L1000 — class Material extends EventDispatcher
- constructor · method · L21-L476 — constructor()
- alphaTest · method · L486-L490 — get alphaTest()
- alphaTest · method · L492-L502 — set alphaTest( value )
- onBeforeRender · method · L516-L516 — onBeforeRender( /* renderer, scene, camera, geometry, object, group */ )
- onBeforeCompile · method · L530-L530 — onBeforeCompile( /* shaderobject, renderer */ )
- customProgramCacheKey · method · L541-L545 — customProgramCacheKey()
- setValues · method · L554-L594 — setValues( values )
- toJSON · method · L603-L868 — toJSON( meta )
- extractFromCache · function · L840-L854 — function extractFromCache( cache )
- clone · method · L875-L879 — clone()
- copy · method · L887-L966 — copy( source )
- dispose · method · L974-L984 — dispose()
- needsUpdate · method · L994-L998 — set needsUpdate( value )
