# src/materials/LineDashedMaterial.js

- LineDashedMaterial · class · L19-L84 — class LineDashedMaterial extends LineBasicMaterial
- constructor · method · L30-L70 — constructor( parameters )
- copy · method · L72-L82 — copy( source )
