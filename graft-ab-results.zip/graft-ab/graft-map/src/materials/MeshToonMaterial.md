# src/materials/MeshToonMaterial.js

- MeshToonMaterial · class · L11-L318 — class MeshToonMaterial extends Material
- constructor · method · L22-L273 — constructor( parameters )
- copy · method · L275-L316 — copy( source )
