# src/materials/MeshMatcapMaterial.js

- MeshMatcapMaterial · class · L17-L221 — class MeshMatcapMaterial extends Material
- constructor · method · L28-L185 — constructor( parameters )
- copy · method · L188-L219 — copy( source )
