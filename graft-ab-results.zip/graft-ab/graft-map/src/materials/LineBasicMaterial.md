# src/materials/LineBasicMaterial.js

- LineBasicMaterial · class · L15-L120 — class LineBasicMaterial extends Material
- constructor · method · L26-L100 — constructor( parameters )
- copy · method · L102-L118 — copy( source )
