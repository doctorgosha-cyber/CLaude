# src/materials/PointsMaterial.js

- PointsMaterial · class · L29-L137 — class PointsMaterial extends Material
- constructor · method · L40-L116 — constructor( parameters )
- copy · method · L118-L135 — copy( source )
