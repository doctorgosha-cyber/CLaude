# src/materials/nodes/SpriteNodeMaterial.js

- SpriteNodeMaterial · class · L19-L196 — class SpriteNodeMaterial extends NodeMaterial
- type · method · L21-L25 — static get type()
- constructor · method · L32-L101 — constructor( parameters )
- setupPositionView · method · L110-L161 — setupPositionView( builder )
- copy · method · L163-L171 — copy( source )
- sizeAttenuation · method · L179-L183 — get sizeAttenuation()
- sizeAttenuation · method · L185-L194 — set sizeAttenuation( value )
