# src/materials/nodes/VolumeNodeMaterial.js

- VolumeNodeMaterial · class · L10-L79 — class VolumeNodeMaterial extends NodeMaterial
- type · method · L12-L16 — static get type()
- constructor · method · L23-L71 — constructor( parameters )
- setupLightingModel · method · L73-L77 — setupLightingModel()
