# src/materials/nodes/MeshNormalNodeMaterial.js

- MeshNormalNodeMaterial · class · L19-L65 — class MeshNormalNodeMaterial extends NodeMaterial
- type · method · L21-L25 — static get type()
- constructor · method · L32-L49 — constructor( parameters )
- setupDiffuseColor · method · L55-L63 — setupDiffuseColor()
