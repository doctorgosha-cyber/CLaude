# src/materials/nodes/LineDashedNodeMaterial.js

- LineDashedNodeMaterial · class · L16-L130 — class LineDashedNodeMaterial extends NodeMaterial
- type · method · L18-L22 — static get type()
- constructor · method · L29-L106 — constructor( parameters )
- setupVariants · method · L113-L128 — setupVariants( /* builder */ )
