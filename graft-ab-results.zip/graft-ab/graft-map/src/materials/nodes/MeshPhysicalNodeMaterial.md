# src/materials/nodes/MeshPhysicalNodeMaterial.js

- MeshPhysicalNodeMaterial · class · L20-L516 — class MeshPhysicalNodeMaterial extends MeshStandardNodeMaterial
- type · method · L22-L26 — static get type()
- constructor · method · L33-L271 — constructor( parameters )
- useClearcoat · method · L279-L283 — get useClearcoat()
- useIridescence · method · L291-L295 — get useIridescence()
- useSheen · method · L303-L307 — get useSheen()
- useAnisotropy · method · L315-L319 — get useAnisotropy()
- useTransmission · method · L327-L331 — get useTransmission()
- useDispersion · method · L339-L343 — get useDispersion()
- setupSpecular · method · L348-L356 — setupSpecular()
- setupLightingModel · method · L363-L367 — setupLightingModel( /*builder*/ )
- setupVariants · method · L374-L467 — setupVariants( builder )
- setupClearcoatNormal · method · L474-L478 — setupClearcoatNormal()
- setup · method · L480-L486 — setup( builder )
- copy · method · L488-L514 — copy( source )
