# src/materials/nodes/MeshPhongNodeMaterial.js

- MeshPhongNodeMaterial · class · L17-L139 — class MeshPhongNodeMaterial extends NodeMaterial
- type · method · L19-L23 — static get type()
- constructor · method · L30-L81 — constructor( parameters )
- setupEnvironment · method · L90-L96 — setupEnvironment( builder )
- setupLightingModel · method · L103-L107 — setupLightingModel( /*builder*/ )
- setupVariants · method · L114-L128 — setupVariants( /*builder*/ )
- copy · method · L130-L137 — copy( source )
