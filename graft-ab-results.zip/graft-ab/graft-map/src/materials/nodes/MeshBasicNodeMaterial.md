# src/materials/nodes/MeshBasicNodeMaterial.js

- MeshBasicNodeMaterial · class · L19-L132 — class MeshBasicNodeMaterial extends NodeMaterial
- type · method · L21-L25 — static get type()
- constructor · method · L32-L59 — constructor( parameters )
- setupNormal · method · L67-L71 — setupNormal()
- setupEnvironment · method · L80-L86 — setupEnvironment( builder )
- setupLightMap · method · L95-L107 — setupLightMap( builder )
- setupOutgoingLight · method · L115-L119 — setupOutgoingLight()
- setupLightingModel · method · L126-L130 — setupLightingModel()
