# src/materials/nodes/MeshMatcapNodeMaterial.js

- MeshMatcapNodeMaterial · class · L17-L74 — class MeshMatcapNodeMaterial extends NodeMaterial
- type · method · L19-L23 — static get type()
- constructor · method · L30-L47 — constructor( parameters )
- setupVariants · method · L54-L72 — setupVariants( builder )
