# src/materials/nodes/ShadowNodeMaterial.js

- ShadowNodeMaterial · class · L13-L74 — class ShadowNodeMaterial extends NodeMaterial
- type · method · L15-L19 — static get type()
- constructor · method · L26-L61 — constructor( parameters )
- setupLightingModel · method · L68-L72 — setupLightingModel( /*builder*/ )
