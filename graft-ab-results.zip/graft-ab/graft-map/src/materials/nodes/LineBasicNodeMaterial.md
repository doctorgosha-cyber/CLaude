# src/materials/nodes/LineBasicNodeMaterial.js

- LineBasicNodeMaterial · class · L12-L44 — class LineBasicNodeMaterial extends NodeMaterial
- type · method · L14-L18 — static get type()
- constructor · method · L25-L42 — constructor( parameters )
