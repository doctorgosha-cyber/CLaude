# src/materials/nodes/Line2NodeMaterial.js

- Line2NodeMaterial · class · L25-L540 — class Line2NodeMaterial extends NodeMaterial
- type · method · L27-L31 — static get type()
- constructor · method · L38-L124 — constructor( parameters = {} )
- setup · method · L131-L468 — setup( builder )
- worldUnits · method · L477-L481 — get worldUnits()
- worldUnits · method · L483-L492 — set worldUnits( value )
- dashed · method · L500-L504 — get dashed()
- dashed · method · L506-L515 — set dashed( value )
- alphaToCoverage · method · L523-L527 — get alphaToCoverage()
- alphaToCoverage · method · L529-L538 — set alphaToCoverage( value )
