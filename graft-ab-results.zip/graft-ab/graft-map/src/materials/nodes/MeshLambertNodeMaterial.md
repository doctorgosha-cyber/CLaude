# src/materials/nodes/MeshLambertNodeMaterial.js

- MeshLambertNodeMaterial · class · L14-L80 — class MeshLambertNodeMaterial extends NodeMaterial
- type · method · L16-L20 — static get type()
- constructor · method · L27-L52 — constructor( parameters )
- setupEnvironment · method · L61-L67 — setupEnvironment( builder )
- setupLightingModel · method · L74-L78 — setupLightingModel( /*builder*/ )
