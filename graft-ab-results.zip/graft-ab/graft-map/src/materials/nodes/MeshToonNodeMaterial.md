# src/materials/nodes/MeshToonNodeMaterial.js

- MeshToonNodeMaterial · class · L13-L64 — class MeshToonNodeMaterial extends NodeMaterial
- type · method · L15-L19 — static get type()
- constructor · method · L26-L51 — constructor( parameters )
- setupLightingModel · method · L58-L62 — setupLightingModel( /*builder*/ )
