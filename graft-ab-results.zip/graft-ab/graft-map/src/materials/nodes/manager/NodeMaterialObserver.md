# src/materials/nodes/manager/NodeMaterialObserver.js

- NodeMaterialObserver · class · L73-L610 — class NodeMaterialObserver
- constructor · method · L80-L119 — constructor( builder )
- firstInitialization · method · L127-L141 — firstInitialization( renderObject )
- needsVelocity · method · L149-L155 — needsVelocity( renderer )
- getRenderObjectData · method · L163-L217 — getRenderObjectData( renderObject )
- getAttributesData · method · L226-L242 — getAttributesData( attributes )
- containsNode · method · L251-L267 — containsNode( builder )
- getMaterialData · method · L276-L308 — getMaterialData( material )
- equals · method · L317-L518 — equals( renderObject, lightsData )
- getLightsData · method · L526-L544 — getLightsData( materialLights )
- getLights · method · L553-L573 — getLights( lightsNode, renderId )
- needsRefresh · method · L582-L608 — needsRefresh( renderObject, nodeFrame )
