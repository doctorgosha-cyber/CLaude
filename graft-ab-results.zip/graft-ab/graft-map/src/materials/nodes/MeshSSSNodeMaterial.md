# src/materials/nodes/MeshSSSNodeMaterial.js

- SSSLightingModel · class · L12-L67 — class SSSLightingModel extends PhysicalLightingModel
- constructor · method · L25-L37 — constructor( clearcoat = false, sheen = false, iridescence = false, anisotropy = false, transmission = false, dispersion = false, sss = false )
- direct · method · L47-L65 — direct( { lightDirection, lightColor, reflectedLight }, builder )
- MeshSSSNodeMaterial · class · L75-L173 — class MeshSSSNodeMaterial extends MeshPhysicalNodeMaterial
- type · method · L77-L81 — static get type()
- constructor · method · L88-L135 — constructor( parameters )
- useSSS · method · L143-L147 — get useSSS()
- setupLightingModel · method · L154-L158 — setupLightingModel( /*builder*/ )
- copy · method · L160-L171 — copy( source )
