# src/materials/nodes/MeshStandardNodeMaterial.js

- MeshStandardNodeMaterial · class · L19-L184 — class MeshStandardNodeMaterial extends NodeMaterial
- type · method · L21-L25 — static get type()
- constructor · method · L32-L96 — constructor( parameters )
- setupEnvironment · method · L106-L118 — setupEnvironment( builder )
- setupLightingModel · method · L125-L129 — setupLightingModel( /*builder*/ )
- setupSpecular · method · L134-L141 — setupSpecular()
- setupVariants · method · L148-L171 — setupVariants()
- copy · method · L173-L182 — copy( source )
