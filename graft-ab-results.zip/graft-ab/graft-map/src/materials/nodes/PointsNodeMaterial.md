# src/materials/nodes/PointsNodeMaterial.js

- PointsNodeMaterial · class · L18-L156 — class PointsNodeMaterial extends SpriteNodeMaterial
- type · method · L20-L24 — static get type()
- constructor · method · L31-L61 — constructor( parameters )
- setupPositionView · method · L63-L69 — setupPositionView()
- setupVertex · method · L71-L131 — setupVertex( builder )
- alphaToCoverage · method · L139-L143 — get alphaToCoverage()
- alphaToCoverage · method · L145-L154 — set alphaToCoverage( value )
