# src/materials/MeshLambertMaterial.js

- MeshLambertMaterial · class · L23-L390 — class MeshLambertMaterial extends Material
- constructor · method · L34-L336 — constructor( parameters )
- copy · method · L338-L388 — copy( source )
