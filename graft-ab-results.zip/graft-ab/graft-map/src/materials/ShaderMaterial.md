# src/materials/ShaderMaterial.js

- ShaderMaterial · class · L39-L381 — class ShaderMaterial extends Material
- constructor · method · L50-L257 — constructor( parameters )
- copy · method · L259-L284 — copy( source )
- toJSON · method · L286-L379 — toJSON( meta )
