# src/materials/MeshPhysicalMaterial.js

- MeshPhysicalMaterial · class · L31-L533 — class MeshPhysicalMaterial extends MeshStandardMaterial
- constructor · method · L42-L323 — constructor( parameters )
- anisotropy · method · L331-L335 — get anisotropy()
- anisotropy · method · L337-L347 — set anisotropy( value )
- clearcoat · method · L357-L361 — get clearcoat()
- clearcoat · method · L363-L373 — set clearcoat( value )
- iridescence · method · L381-L385 — get iridescence()
- iridescence · method · L387-L397 — set iridescence( value )
- dispersion · method · L407-L411 — get dispersion()
- dispersion · method · L413-L423 — set dispersion( value )
- sheen · method · L431-L435 — get sheen()
- sheen · method · L437-L447 — set sheen( value )
- transmission · method · L461-L465 — get transmission()
- transmission · method · L467-L477 — set transmission( value )
- copy · method · L479-L531 — copy( source )
