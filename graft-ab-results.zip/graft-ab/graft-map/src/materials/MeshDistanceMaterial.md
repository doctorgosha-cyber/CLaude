# src/materials/MeshDistanceMaterial.js

- MeshDistanceMaterial · class · L14-L117 — class MeshDistanceMaterial extends Material
- constructor · method · L25-L99 — constructor( parameters )
- copy · method · L101-L115 — copy( source )
