# src/materials/MeshNormalMaterial.js

- MeshNormalMaterial · class · L10-L172 — class MeshNormalMaterial extends Material
- constructor · method · L21-L146 — constructor( parameters )
- copy · method · L148-L170 — copy( source )
