# src/materials/SpriteMaterial.js

- SpriteMaterial · class · L18-L134 — class SpriteMaterial extends Material
- constructor · method · L29-L112 — constructor( parameters )
- copy · method · L114-L132 — copy( source )
