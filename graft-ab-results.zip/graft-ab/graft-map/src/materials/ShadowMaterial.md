# src/materials/ShadowMaterial.js

- ShadowMaterial · class · L22-L89 — class ShadowMaterial extends Material
- constructor · method · L33-L75 — constructor( parameters )
- copy · method · L77-L87 — copy( source )
