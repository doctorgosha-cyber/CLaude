# src/materials/RawShaderMaterial.js

- RawShaderMaterial · class · L12-L40 — class RawShaderMaterial extends ShaderMaterial
- constructor · method · L23-L38 — constructor( parameters )
