# src/materials/MeshPhongMaterial.js

- MeshPhongMaterial · class · L21-L409 — class MeshPhongMaterial extends Material
- constructor · method · L32-L353 — constructor( parameters )
- copy · method · L355-L407 — copy( source )
