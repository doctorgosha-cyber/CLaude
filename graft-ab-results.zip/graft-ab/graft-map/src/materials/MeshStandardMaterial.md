# src/materials/MeshStandardMaterial.js

- MeshStandardMaterial · class · L40-L422 — class MeshStandardMaterial extends Material
- constructor · method · L51-L364 — constructor( parameters )
- copy · method · L366-L420 — copy( source )
