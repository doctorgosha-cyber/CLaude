# src/materials/MeshBasicMaterial.js

- MeshBasicMaterial · class · L13-L247 — class MeshBasicMaterial extends Material
- constructor · method · L24-L210 — constructor( parameters )
- copy · method · L212-L245 — copy( source )
