# src/materials/MeshDepthMaterial.js

- MeshDepthMaterial · class · L10-L145 — class MeshDepthMaterial extends Material
- constructor · method · L21-L122 — constructor( parameters )
- copy · method · L124-L143 — copy( source )
