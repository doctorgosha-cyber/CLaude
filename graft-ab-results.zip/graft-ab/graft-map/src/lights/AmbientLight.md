# src/lights/AmbientLight.js

- AmbientLight · class · L15-L40 — class AmbientLight extends Light
- constructor · method · L23-L38 — constructor( color, intensity )
