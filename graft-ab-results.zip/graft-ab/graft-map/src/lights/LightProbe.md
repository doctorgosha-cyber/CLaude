# src/lights/LightProbe.js

- LightProbe · class · L23-L88 — class LightProbe extends Light
- constructor · method · L31-L51 — constructor( sh = new SphericalHarmonics3(), intensity = 1 )
- copy · method · L53-L61 — copy( source )
- fromJSON · method · L69-L76 — fromJSON( json )
- toJSON · method · L78-L86 — toJSON( meta )
