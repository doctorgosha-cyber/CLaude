# src/lights/DirectionalLightShadow.js

- DirectionalLightShadow · class · L9-L29 — class DirectionalLightShadow extends LightShadow
- constructor · method · L14-L27 — constructor()
