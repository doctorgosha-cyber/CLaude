# src/lights/SpotLightShadow.js

- SpotLightShadow · class · L10-L78 — class SpotLightShadow extends LightShadow
- constructor · method · L15-L45 — constructor()
- updateMatrices · method · L47-L66 — updateMatrices( light )
- copy · method · L68-L76 — copy( source )
