# src/lights/RectAreaLight.js

- RectAreaLight · class · L28-L113 — class RectAreaLight extends Light
- constructor · method · L38-L69 — constructor( color, intensity, width = 10, height = 10 )
- power · method · L77-L82 — get power()
- power · method · L84-L89 — set power( power )
- copy · method · L91-L100 — copy( source )
- toJSON · method · L102-L111 — toJSON( meta )
