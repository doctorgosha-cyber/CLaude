# src/lights/SpotLight.js

- SpotLight · class · L27-L171 — class SpotLight extends Light
- constructor · method · L39-L125 — constructor( color, intensity, distance = 0, angle = Math.PI / 3, penumbra = 0, decay = 2 )
- power · method · L133-L139 — get power()
- power · method · L141-L146 — set power( power )
- dispose · method · L148-L152 — dispose()
- copy · method · L154-L169 — copy( source, recursive )
