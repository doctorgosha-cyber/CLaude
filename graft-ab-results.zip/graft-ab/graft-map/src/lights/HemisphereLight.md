# src/lights/HemisphereLight.js

- HemisphereLight · class · L18-L64 — class HemisphereLight extends Light
- constructor · method · L27-L52 — constructor( skyColor, groundColor, intensity )
- copy · method · L54-L62 — copy( source, recursive )
