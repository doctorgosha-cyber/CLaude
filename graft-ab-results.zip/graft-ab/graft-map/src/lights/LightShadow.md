# src/lights/LightShadow.js

- LightShadow · class · L18-L336 — class LightShadow
- constructor · method · L25-L164 — constructor( camera )
- getViewportCount · method · L172-L176 — getViewportCount()
- getFrustum · method · L183-L187 — getFrustum()
- updateMatrices · method · L194-L231 — updateMatrices( light )
- getViewport · method · L239-L243 — getViewport( viewportIndex )
- getFrameExtents · method · L250-L254 — getFrameExtents()
- dispose · method · L260-L274 — dispose()
- copy · method · L282-L300 — copy( source )
- clone · method · L307-L311 — clone()
- toJSON · method · L319-L334 — toJSON()
