# src/lights/Light.js

- Light · class · L11-L93 — class Light extends Object3D
- constructor · method · L19-L49 — constructor( color, intensity = 1 )
- dispose · method · L55-L59 — dispose()
- copy · method · L61-L70 — copy( source, recursive )
- toJSON · method · L72-L91 — toJSON( meta )
