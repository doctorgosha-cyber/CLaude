# src/lights/PointLightShadow.js

- PointLightShadow · class · L17-L115 — class PointLightShadow extends LightShadow
- constructor · method · L22-L77 — constructor()
- updateMatrices · method · L85-L113 — updateMatrices( light, viewportIndex = 0 )
