# src/lights/PointLight.js

- PointLight · class · L19-L114 — class PointLight extends Light
- constructor · method · L29-L72 — constructor( color, intensity, distance = 0, decay = 2 )
- power · method · L80-L86 — get power()
- power · method · L88-L93 — set power( power )
- dispose · method · L95-L99 — dispose()
- copy · method · L101-L112 — copy( source, recursive )
