# src/lights/DirectionalLight.js

- DirectionalLight · class · L32-L98 — class DirectionalLight extends Light
- constructor · method · L40-L79 — constructor( color, intensity )
- dispose · method · L81-L85 — dispose()
- copy · method · L87-L96 — copy( source )
