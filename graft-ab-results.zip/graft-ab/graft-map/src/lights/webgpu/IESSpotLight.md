# src/lights/webgpu/IESSpotLight.js

- IESSpotLight · class · L8-L44 — class IESSpotLight extends SpotLight
- constructor · method · L20-L32 — constructor( color, intensity, distance, angle, penumbra, decay )
- copy · method · L34-L42 — copy( source, recursive )
