# src/lights/webgpu/ProjectorLight.js

- ProjectorLight · class · L8-L44 — class ProjectorLight extends SpotLight
- constructor · method · L20-L32 — constructor( color, intensity, distance, angle, penumbra, decay )
- copy · method · L34-L42 — copy( source, recursive )
