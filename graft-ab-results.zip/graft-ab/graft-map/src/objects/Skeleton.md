# src/objects/Skeleton.js

- Skeleton · class · L36-L380 — class Skeleton
- constructor · method · L45-L83 — constructor( bones = [], boneInverses = [] )
- init · method · L90-L123 — init()
- calculateInverses · method · L129-L147 — calculateInverses()
- pose · method · L152-L193 — pose()
- update · method · L198-L224 — update()
- clone · method · L231-L235 — clone()
- computeBoneTexture · method · L242-L266 — computeBoneTexture()
- getBoneByName · method · L275-L291 — getBoneByName( name )
- dispose · method · L297-L307 — dispose( )
- fromJSON · method · L316-L341 — fromJSON( json, bones )
- toJSON · method · L349-L378 — toJSON()
