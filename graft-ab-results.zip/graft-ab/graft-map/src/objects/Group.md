# src/objects/Group.js

- Group · class · L20-L39 — class Group extends Object3D
- constructor · method · L22-L37 — constructor()
