# src/objects/Mesh.js

- Mesh · class · L39-L407 — class Mesh extends Object3D
- constructor · method · L47-L108 — constructor( geometry = new BufferGeometry(), material = new MeshBasicMaterial() )
- copy · method · L110-L131 — copy( source, recursive )
- updateMorphTargets · method · L137-L166 — updateMorphTargets()
- getVertexPosition · method · L176-L218 — getVertexPosition( index, target )
- raycast · method · L226-L270 — raycast( raycaster, intersects )
- _computeIntersections · method · L272-L405 — _computeIntersections( raycaster, intersects, rayLocalSpace )
- checkIntersection · function · L409-L438 — function checkIntersection( object, material, raycaster, ray, pA, pB, pC, point )
- checkGeometryIntersection · function · L440-L494 — function checkGeometryIntersection( object, material, raycaster, ray, uv, uv1, normal, a, b, c )
