# src/objects/SkinnedMesh.js

- SkinnedMesh · class · L36-L349 — class SkinnedMesh extends Mesh
- constructor · method · L44-L99 — constructor( geometry, material )
- computeBoundingBox · method · L107-L128 — computeBoundingBox()
- computeBoundingSphere · method · L136-L157 — computeBoundingSphere()
- copy · method · L159-L174 — copy( source, recursive )
- raycast · method · L176-L209 — raycast( raycaster, intersects )
- getVertexPosition · method · L211-L219 — getVertexPosition( index, target )
- bind · method · L228-L245 — bind( skeleton, bindMatrix )
- pose · method · L250-L254 — pose()
- normalizeSkinWeights · method · L260-L286 — normalizeSkinWeights()
- updateMatrixWorld · method · L288-L306 — updateMatrixWorld( force )
- applyBoneTransform · method · L317-L347 — applyBoneTransform( index, target )
