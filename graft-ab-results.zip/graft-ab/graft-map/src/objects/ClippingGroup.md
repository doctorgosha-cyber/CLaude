# src/objects/ClippingGroup.js

- ClippingGroup · class · L15-L66 — class ClippingGroup extends Group
- constructor · method · L20-L64 — constructor()
