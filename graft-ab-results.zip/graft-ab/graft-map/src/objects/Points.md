# src/objects/Points.js

- Points · class · L19-L194 — class Points extends Object3D
- constructor · method · L27-L79 — constructor( geometry = new BufferGeometry(), material = new PointsMaterial() )
- copy · method · L81-L90 — copy( source, recursive )
- raycast · method · L98-L157 — raycast( raycaster, intersects )
- updateMorphTargets · method · L163-L192 — updateMorphTargets()
- testPoint · function · L196-L226 — function testPoint( point, index, localThresholdSq, matrixWorld, raycaster, intersects, object )
