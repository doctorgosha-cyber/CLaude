# src/objects/Sprite.js

- Sprite · class · L46-L215 — class Sprite extends Object3D
- constructor · method · L53-L120 — constructor( material = new SpriteMaterial() )
- raycast · method · L128-L201 — raycast( raycaster, intersects )
- copy · method · L203-L213 — copy( source, recursive )
- transformVertex · function · L217-L242 — function transformVertex( vertexPosition, mvPosition, center, scale, sin, cos )
