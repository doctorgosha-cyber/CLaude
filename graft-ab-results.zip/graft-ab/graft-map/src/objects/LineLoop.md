# src/objects/LineLoop.js

- LineLoop · class · L10-L35 — class LineLoop extends Line
- constructor · method · L18-L33 — constructor( geometry, material )
