# src/objects/LineSegments.js

- LineSegments · class · L13-L71 — class LineSegments extends Line
- constructor · method · L21-L36 — constructor( geometry, material )
- computeLineDistances · method · L38-L69 — computeLineDistances()
