# src/objects/Line.js

- Line · class · L40-L293 — class Line extends Object3D
- constructor · method · L48-L100 — constructor( geometry = new BufferGeometry(), material = new LineBasicMaterial() )
- copy · method · L102-L111 — copy( source, recursive )
- computeLineDistances · method · L120-L151 — computeLineDistances()
- raycast · method · L159-L256 — raycast( raycaster, intersects )
- updateMorphTargets · method · L262-L291 — updateMorphTargets()
- checkIntersection · function · L295-L326 — function checkIntersection( object, raycaster, ray, thresholdSq, a, b, i )
