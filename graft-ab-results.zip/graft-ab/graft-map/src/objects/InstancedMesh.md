# src/objects/InstancedMesh.js

- InstancedMesh · class · L28-L393 — class InstancedMesh extends Mesh
- constructor · method · L37-L108 — constructor( geometry, material, count )
- computeBoundingBox · method · L115-L144 — computeBoundingBox()
- computeBoundingSphere · method · L151-L180 — computeBoundingSphere()
- copy · method · L182-L198 — copy( source, recursive )
- getColorAt · method · L206-L210 — getColorAt( index, color )
- getMatrixAt · method · L218-L222 — getMatrixAt( index, matrix )
- getMorphAt · method · L230-L246 — getMorphAt( index, object )
- raycast · method · L248-L298 — raycast( raycaster, intersects )
- setColorAt · method · L307-L317 — setColorAt( index, color )
- setMatrixAt · method · L326-L330 — setMatrixAt( index, matrix )
- setMorphAt · method · L340-L370 — setMorphAt( index, object )
- updateMorphTargets · method · L372-L374 — updateMorphTargets()
- dispose · method · L380-L391 — dispose()
