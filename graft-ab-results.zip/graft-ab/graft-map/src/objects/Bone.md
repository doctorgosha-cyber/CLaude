# src/objects/Bone.js

- Bone · class · L17-L39 — class Bone extends Object3D
- constructor · method · L22-L37 — constructor()
