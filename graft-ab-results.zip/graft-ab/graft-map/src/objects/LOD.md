# src/objects/LOD.js

- LOD · class · L33-L326 — class LOD extends Object3D
- constructor · method · L38-L85 — constructor()
- copy · method · L87-L105 — copy( source )
- addLevel · method · L116-L140 — addLevel( object, distance = 0, hysteresis = 0 )
- removeLevel · method · L149-L168 — removeLevel( distance )
- getCurrentLevel · method · L175-L179 — getCurrentLevel()
- getObjectForDistance · method · L188-L220 — getObjectForDistance( distance )
- raycast · method · L228-L242 — raycast( raycaster, intersects )
- update · method · L250-L298 — update( camera )
- toJSON · method · L300-L324 — toJSON( meta )
