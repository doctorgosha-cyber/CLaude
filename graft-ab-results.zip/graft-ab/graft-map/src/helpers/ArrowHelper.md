# src/helpers/ArrowHelper.js

- ArrowHelper · class · L33-L169 — class ArrowHelper extends Object3D
- constructor · method · L45-L84 — constructor( dir = new Vector3( 0, 0, 1 ), origin = new Vector3( 0, 0, 0 ), length = 1, color = 0xffff00, headLength = length * 0.2, headWidth = headLength * 0.2 )
- setDirection · method · L91-L113 — setDirection( dir )
- setLength · method · L122-L131 — setLength( length, headLength = length * 0.2, headWidth = headLength * 0.2 )
- setColor · method · L138-L143 — setColor( color )
- copy · method · L145-L154 — copy( source )
- dispose · method · L160-L167 — dispose()
