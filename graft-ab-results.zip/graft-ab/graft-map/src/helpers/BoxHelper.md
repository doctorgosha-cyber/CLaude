# src/helpers/BoxHelper.js

- BoxHelper · class · L26-L146 — class BoxHelper extends LineSegments
- constructor · method · L34-L57 — constructor( object, color = 0xffff00 )
- update · method · L63-L108 — update()
- setFromObject · method · L116-L123 — setFromObject( object )
- copy · method · L125-L133 — copy( source, recursive )
- dispose · method · L139-L144 — dispose()
