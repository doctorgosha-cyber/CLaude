# src/helpers/DirectionalLightHelper.js

- DirectionalLightHelper · class · L27-L142 — class DirectionalLightHelper extends Object3D
- constructor · method · L37-L95 — constructor( light, size, color )
- dispose · method · L101-L108 — dispose()
- update · method · L114-L140 — update()
