# src/helpers/AxesHelper.js

- AxesHelper · class · L18-L93 — class AxesHelper extends LineSegments
- constructor · method · L25-L49 — constructor( size = 1 )
- setColors · method · L59-L80 — setColors( xAxisColor, yAxisColor, zAxisColor )
- dispose · method · L86-L91 — dispose()
