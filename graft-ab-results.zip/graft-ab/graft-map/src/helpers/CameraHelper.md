# src/helpers/CameraHelper.js

- CameraHelper · class · L29-L319 — class CameraHelper extends LineSegments
- constructor · method · L36-L152 — constructor( camera )
- addLine · function · L93-L98 — function addLine( a, b )
- addPoint · function · L100-L113 — function addPoint( id )
- setColors · method · L164-L221 — setColors( frustum, cone, up, target, cross )
- update · method · L226-L306 — update()
- dispose · method · L312-L317 — dispose()
- setPoint · function · L322-L340 — function setPoint( point, pointMap, geometry, camera, x, y, z )
