# src/helpers/Box3Helper.js

- Box3Helper · class · L19-L81 — class Box3Helper extends LineSegments
- constructor · method · L27-L52 — constructor( box, color = 0xffff00 )
- updateMatrixWorld · method · L54-L68 — updateMatrixWorld( force )
- dispose · method · L74-L79 — dispose()
