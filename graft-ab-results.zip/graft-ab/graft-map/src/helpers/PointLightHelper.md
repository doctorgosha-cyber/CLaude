# src/helpers/PointLightHelper.js

- PointLightHelper · class · L21-L132 — class PointLightHelper extends Mesh
- constructor · method · L31-L84 — constructor( light, sphereSize, color )
- dispose · method · L90-L95 — dispose()
- update · method · L101-L130 — update()
