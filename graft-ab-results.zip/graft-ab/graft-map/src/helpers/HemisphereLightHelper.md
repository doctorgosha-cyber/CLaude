# src/helpers/HemisphereLightHelper.js

- HemisphereLightHelper · class · L25-L124 — class HemisphereLightHelper extends Object3D
- constructor · method · L35-L74 — constructor( light, size, color )
- dispose · method · L80-L85 — dispose()
- update · method · L91-L122 — update()
