# src/helpers/PolarGridHelper.js

- PolarGridHelper · class · L23-L123 — class PolarGridHelper extends LineSegments
- constructor · method · L35-L110 — constructor( radius = 10, sectors = 16, rings = 8, divisions = 64, color1 = 0x444444, color2 = 0x888888 )
- dispose · method · L116-L121 — dispose()
