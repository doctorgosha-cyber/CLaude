# src/helpers/PlaneHelper.js

- PlaneHelper · class · L19-L94 — class PlaneHelper extends Line
- constructor · method · L28-L65 — constructor( plane, size = 1, hex = 0xffff00 )
- updateMatrixWorld · method · L67-L79 — updateMatrixWorld( force )
- dispose · method · L85-L92 — dispose()
