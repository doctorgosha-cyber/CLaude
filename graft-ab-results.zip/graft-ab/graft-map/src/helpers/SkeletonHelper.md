# src/helpers/SkeletonHelper.js

- SkeletonHelper · class · L23-L170 — class SkeletonHelper extends LineSegments
- constructor · method · L31-L97 — constructor( object )
- updateMatrixWorld · method · L99-L132 — updateMatrixWorld( force )
- setColors · method · L141-L157 — setColors( color1, color2 )
- dispose · method · L163-L168 — dispose()
- getBoneList · function · L173-L191 — function getBoneList( object )
