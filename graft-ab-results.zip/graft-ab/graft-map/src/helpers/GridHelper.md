# src/helpers/GridHelper.js

- GridHelper · class · L21-L79 — class GridHelper extends LineSegments
- constructor · method · L31-L66 — constructor( size = 10, divisions = 10, color1 = 0x444444, color2 = 0x888888 )
- dispose · method · L72-L77 — dispose()
