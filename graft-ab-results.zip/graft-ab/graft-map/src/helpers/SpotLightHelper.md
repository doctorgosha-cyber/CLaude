# src/helpers/SpotLightHelper.js

- SpotLightHelper · class · L24-L148 — class SpotLightHelper extends Object3D
- constructor · method · L33-L87 — constructor( light, color )
- dispose · method · L93-L98 — dispose()
- update · method · L104-L146 — update()
