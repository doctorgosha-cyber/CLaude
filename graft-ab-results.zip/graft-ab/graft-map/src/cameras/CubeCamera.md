# src/cameras/CubeCamera.js

- CubeCamera · class · L38-L237 — class CubeCamera extends Object3D
- constructor · method · L47-L100 — constructor( near, far, renderTarget )
- updateCoordinateSystem · method · L105-L169 — updateCoordinateSystem()
- update · method · L178-L235 — update( renderer, scene )
