# src/cameras/ArrayCamera.js

- ArrayCamera · class · L14-L52 — class ArrayCamera extends PerspectiveCamera
- constructor · method · L21-L50 — constructor( array = [] )
