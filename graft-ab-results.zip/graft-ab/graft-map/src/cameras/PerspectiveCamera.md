# src/cameras/PerspectiveCamera.js

- PerspectiveCamera · class · L23-L405 — class PerspectiveCamera extends Camera
- constructor · method · L33-L133 — constructor( fov = 50, aspect = 1, near = 0.1, far = 2000 )
- copy · method · L135-L154 — copy( source, recursive )
- setFocalLength · method · L164-L172 — setFocalLength( focalLength )
- getFocalLength · method · L180-L186 — getFocalLength()
- getEffectiveFOV · method · L193-L198 — getEffectiveFOV()
- getFilmWidth · method · L206-L211 — getFilmWidth()
- getFilmHeight · method · L219-L224 — getFilmHeight()
- getViewBounds · method · L234-L244 — getViewBounds( distance, minTarget, maxTarget )
- getViewSize · method · L253-L259 — getViewSize( distance, target )
- setViewOffset · method · L304-L332 — setViewOffset( fullWidth, fullHeight, x, y, width, height )
- clearViewOffset · method · L337-L347 — clearViewOffset()
- updateProjectionMatrix · method · L353-L381 — updateProjectionMatrix()
- toJSON · method · L383-L403 — toJSON( meta )
