# src/cameras/OrthographicCamera.js

- OrthographicCamera · class · L17-L243 — class OrthographicCamera extends Camera
- constructor · method · L29-L116 — constructor( left = - 1, right = 1, top = 1, bottom = - 1, near = 0.1, far = 2000 )
- copy · method · L118-L134 — copy( source, recursive )
- setViewOffset · method · L148-L174 — setViewOffset( fullWidth, fullHeight, x, y, width, height )
- clearViewOffset · method · L179-L189 — clearViewOffset()
- updateProjectionMatrix · method · L195-L223 — updateProjectionMatrix()
- toJSON · method · L225-L241 — toJSON( meta )
