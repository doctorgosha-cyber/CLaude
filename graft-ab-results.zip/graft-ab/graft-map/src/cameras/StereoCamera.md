# src/cameras/StereoCamera.js

- StereoCamera · class · L15-L144 — class StereoCamera
- constructor · method · L20-L78 — constructor()
- update · method · L85-L142 — update( camera )
