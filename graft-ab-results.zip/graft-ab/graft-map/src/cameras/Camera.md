# src/cameras/Camera.js

- Camera · class · L12-L128 — class Camera extends Object3D
- constructor · method · L17-L62 — constructor()
- reversedDepth · method · L70-L74 — get reversedDepth()
- copy · method · L76-L89 — copy( source, recursive )
- getWorldDirection · method · L100-L104 — getWorldDirection( target )
- updateMatrixWorld · method · L106-L112 — updateMatrixWorld( force )
- updateWorldMatrix · method · L114-L120 — updateWorldMatrix( updateParents, updateChildren )
- clone · method · L122-L126 — clone()
