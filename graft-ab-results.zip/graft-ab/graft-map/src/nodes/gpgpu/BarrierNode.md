# src/nodes/gpgpu/BarrierNode.js

- BarrierNode · class · L11-L43 — class BarrierNode extends Node
- constructor · method · L18-L24 — constructor( scope )
- generate · method · L26-L41 — generate( builder )
- workgroupBarrier · function · L66-L66 — workgroupBarrier = ()
- storageBarrier · function · L77-L77 — storageBarrier = ()
- textureBarrier · function · L88-L88 — textureBarrier = ()
