# src/nodes/gpgpu/AtomicFunctionNode.js

- AtomicFunctionNode · class · L16-L136 — class AtomicFunctionNode extends Node
- type · method · L18-L22 — static get type()
- constructor · method · L31-L64 — constructor( method, pointerNode, valueNode )
- getInputType · method · L73-L77 — getInputType( builder )
- getNodeType · method · L85-L89 — getNodeType( builder )
- generate · method · L91-L134 — generate( builder )
- atomicFunc · function · L172-L176 — atomicFunc = ( method, pointerNode, valueNode )
- atomicLoad · function · L186-L186 — atomicLoad = ( pointerNode )
- atomicStore · function · L197-L197 — atomicStore = ( pointerNode, valueNode )
- atomicAdd · function · L208-L208 — atomicAdd = ( pointerNode, valueNode )
- atomicSub · function · L219-L219 — atomicSub = ( pointerNode, valueNode )
- atomicMax · function · L230-L230 — atomicMax = ( pointerNode, valueNode )
- atomicMin · function · L241-L241 — atomicMin = ( pointerNode, valueNode )
- atomicAnd · function · L252-L252 — atomicAnd = ( pointerNode, valueNode )
- atomicOr · function · L263-L263 — atomicOr = ( pointerNode, valueNode )
- atomicXor · function · L274-L274 — atomicXor = ( pointerNode, valueNode )
