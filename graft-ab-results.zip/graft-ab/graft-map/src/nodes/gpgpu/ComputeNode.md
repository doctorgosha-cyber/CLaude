# src/nodes/gpgpu/ComputeNode.js

- ComputeNode · class · L10-L216 — class ComputeNode extends Node
- type · method · L12-L16 — static get type()
- constructor · method · L24-L91 — constructor( computeNode, workgroupSize )
- setCount · method · L93-L99 — setCount( count )
- getCount · method · L101-L105 — getCount()
- dispose · method · L110-L114 — dispose()
- setName · method · L122-L128 — setName( name )
- label · method · L137-L143 — label( name )
- onInit · method · L151-L157 — onInit( callback )
- updateBefore · method · L164-L168 — updateBefore( { renderer } )
- setup · method · L170-L185 — setup( builder )
- generate · method · L187-L214 — generate( builder, output )
- computeKernel · function · L229-L257 — computeKernel = ( node, workgroupSize = [ 64 ] )
- compute · function · L269-L269 — compute = ( node, count, workgroupSize )
