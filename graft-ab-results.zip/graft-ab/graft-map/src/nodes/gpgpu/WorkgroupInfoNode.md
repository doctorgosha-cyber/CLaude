# src/nodes/gpgpu/WorkgroupInfoNode.js

- WorkgroupInfoElementNode · class · L10-L54 — class WorkgroupInfoElementNode extends ArrayElementNode
- constructor · method · L18-L31 — constructor( workgroupInfoNode, indexNode )
- generate · method · L33-L52 — generate( builder, output )
- WorkgroupInfoNode · class · L68-L217 — class WorkgroupInfoNode extends Node
- constructor · method · L77-L127 — constructor( scope, bufferType, bufferCount = 0 )
- setName · method · L135-L141 — setName( name )
- label · method · L150-L156 — label( name )
- setScope · method · L164-L170 — setScope( scope )
- getElementType · method · L178-L182 — getElementType()
- getInputType · method · L191-L195 — getInputType( /*builder*/ )
- element · method · L203-L207 — element( indexNode )
- generate · method · L209-L215 — generate( builder )
- workgroupArray · function · L231-L231 — workgroupArray = ( type, count )
