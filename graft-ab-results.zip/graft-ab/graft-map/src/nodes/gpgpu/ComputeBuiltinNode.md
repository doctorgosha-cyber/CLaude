# src/nodes/gpgpu/ComputeBuiltinNode.js

- ComputeBuiltinNode · class · L12-L138 — class ComputeBuiltinNode extends Node
- type · method · L14-L18 — static get type()
- constructor · method · L26-L38 — constructor( builtinName, nodeType )
- getHash · method · L46-L50 — getHash( builder )
- getNodeType · method · L58-L62 — getNodeType( /*builder*/ )
- setBuiltinName · method · L70-L76 — setBuiltinName( builtinName )
- getBuiltinName · method · L84-L88 — getBuiltinName( /*builder*/ )
- hasBuiltin · method · L96-L100 — hasBuiltin( builder )
- generate · method · L102-L118 — generate( builder, output )
- serialize · method · L120-L127 — serialize( data )
- deserialize · method · L129-L136 — deserialize( data )
- computeBuiltin · function · L151-L151 — computeBuiltin = ( name, nodeType )
