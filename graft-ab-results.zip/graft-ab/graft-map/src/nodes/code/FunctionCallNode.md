# src/nodes/code/FunctionCallNode.js

- FunctionCallNode · class · L11-L155 — class FunctionCallNode extends TempNode
- type · method · L13-L17 — static get type()
- constructor · method · L25-L45 — constructor( functionNode = null, parameters = {} )
- setParameters · method · L53-L59 — setParameters( parameters )
- getParameters · method · L66-L70 — getParameters()
- getNodeType · method · L72-L76 — getNodeType( builder )
- generate · method · L78-L153 — generate( builder )
- generateInput · function · L87-L99 — generateInput = ( node, inputNode )
- call · function · L159-L165 — call = ( func, ...params )
