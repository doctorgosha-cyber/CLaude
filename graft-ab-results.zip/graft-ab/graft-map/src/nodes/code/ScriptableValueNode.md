# src/nodes/code/ScriptableValueNode.js

- ScriptableValueNode · class · L12-L241 — class ScriptableValueNode extends Node
- type · method · L14-L18 — static get type()
- constructor · method · L25-L77 — constructor( value = null )
- isScriptableOutputNode · method · L86-L90 — get isScriptableOutputNode()
- value · method · L92-L110 — set value( val )
- value · method · L117-L121 — get value()
- refresh · method · L126-L130 — refresh()
- getValue · method · L138-L163 — getValue()
- getNodeType · method · L171-L175 — getNodeType( builder )
- setup · method · L177-L181 — setup()
- serialize · method · L183-L208 — serialize( data )
- deserialize · method · L210-L239 — deserialize( data )
