# src/nodes/code/ExpressionNode.js

- ExpressionNode · class · L10-L55 — class ExpressionNode extends Node
- type · method · L12-L16 — static get type()
- constructor · method · L24-L36 — constructor( snippet = '', nodeType = 'void' )
- generate · method · L38-L53 — generate( builder, output )
