# src/nodes/code/FunctionNode.js

- FunctionNode · class · L30-L130 — class FunctionNode extends CodeNode
- type · method · L32-L36 — static get type()
- constructor · method · L45-L49 — constructor( code = '', includes = [], language = '' )
- getNodeType · method · L51-L55 — getNodeType( builder )
- getInputs · method · L63-L67 — getInputs( builder )
- getNodeFunction · method · L75-L91 — getNodeFunction( builder )
- generate · method · L93-L128 — generate( builder, output )
- nativeFn · function · L134-L157 — nativeFn = ( code, includes = [], language = '' )
- fn · function · L152-L152 — fn = ( ...params )
- glslFn · function · L159-L159 — glslFn = ( code, includes )
- wgslFn · function · L160-L160 — wgslFn = ( code, includes )
