# src/nodes/code/CodeNode.js

- CodeNode · class · L11-L134 — class CodeNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L26-L71 — constructor( code = '', includes = [], language = '' )
- setIncludes · method · L79-L85 — setIncludes( includes )
- getIncludes · method · L93-L97 — getIncludes( /*builder*/ )
- generate · method · L99-L114 — generate( builder )
- serialize · method · L116-L123 — serialize( data )
- deserialize · method · L125-L132 — deserialize( data )
- js · function · L159-L159 — js = ( src, includes )
- wgsl · function · L170-L170 — wgsl = ( src, includes )
- glsl · function · L181-L181 — glsl = ( src, includes )
