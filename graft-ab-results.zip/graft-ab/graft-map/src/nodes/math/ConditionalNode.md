# src/nodes/math/ConditionalNode.js

- ConditionalNode · class · L18-L212 — class ConditionalNode extends Node
- type · method · L20-L24 — static get type()
- constructor · method · L33-L59 — constructor( condNode, ifNode, elseNode = null )
- getNodeType · method · L68-L98 — getNodeType( builder )
- setup · method · L100-L120 — setup( builder )
- generate · method · L122-L210 — generate( builder, output )
