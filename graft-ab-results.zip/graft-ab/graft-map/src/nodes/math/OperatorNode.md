# src/nodes/math/OperatorNode.js

- OperatorNode · class · L21-L408 — class OperatorNode extends TempNode
- type · method · L23-L27 — static get type()
- constructor · method · L37-L86 — constructor( op, aNode, bNode, ...params )
- getOperatorMethod · method · L95-L99 — getOperatorMethod( builder, output )
- getNodeType · method · L108-L188 — getNodeType( builder )
- generate · method · L190-L390 — generate( builder, output )
- serialize · method · L392-L398 — serialize( data )
- deserialize · method · L400-L406 — deserialize( data )
- modInt · function · L742-L747 — modInt = ( a, b )
