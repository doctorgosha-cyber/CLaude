# src/nodes/math/MathUtils.js

- parabola · function · L15-L15 — parabola = ( x, k )
- gain · function · L28-L28 — gain = ( x, k )
- pcurve · function · L42-L42 — pcurve = ( x, a, b )
- sinc · function · L54-L54 — sinc = ( x, k )
