# src/nodes/core/ArrayNode.js

- ArrayNode · class · L17-L117 — class ArrayNode extends TempNode
- type · method · L19-L23 — static get type()
- constructor · method · L32-L59 — constructor( nodeType, count, values = null )
- getArrayCount · method · L67-L71 — getArrayCount( /*builder*/ )
- getNodeType · method · L79-L89 — getNodeType( builder )
- getElementType · method · L97-L101 — getElementType( builder )
- generate · method · L109-L115 — generate( builder )
- array · function · L131-L152 — array = ( ...params )
