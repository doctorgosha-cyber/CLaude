# src/nodes/core/NodeVarying.js

- NodeVarying · class · L11-L61 — class NodeVarying extends NodeVar
- constructor · method · L21-L59 — constructor( name, type, interpolationType = null, interpolationSampling = null )
