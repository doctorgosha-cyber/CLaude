# src/nodes/core/ParameterNode.js

- ParameterNode · class · L9-L50 — class ParameterNode extends PropertyNode
- type · method · L11-L15 — static get type()
- constructor · method · L23-L36 — constructor( nodeType, name = null )
- getHash · method · L38-L42 — getHash()
- generate · method · L44-L48 — generate()
- parameter · function · L63-L63 — parameter = ( type, name )
