# src/nodes/core/ConstNode.js

- ConstNode · class · L10-L65 — class ConstNode extends InputNode
- type · method · L12-L16 — static get type()
- constructor · method · L24-L37 — constructor( value, nodeType = null )
- generateConst · method · L45-L49 — generateConst( builder )
- generate · method · L51-L63 — generate( builder, output )
