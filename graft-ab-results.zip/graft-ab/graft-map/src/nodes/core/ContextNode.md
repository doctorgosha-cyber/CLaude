# src/nodes/core/ContextNode.js

- ContextNode · class · L14-L119 — class ContextNode extends Node
- type · method · L16-L20 — static get type()
- constructor · method · L28-L56 — constructor( node, value = {} )
- getScope · method · L63-L67 — getScope()
- getNodeType · method · L75-L79 — getNodeType( builder )
- analyze · method · L81-L91 — analyze( builder )
- setup · method · L93-L103 — setup( builder )
- generate · method · L105-L117 — generate( builder, output )
- setName · function · L143-L143 — setName = ( node, name )
- label · function · L155-L161 — function label( node, name )
