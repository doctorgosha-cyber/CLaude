# src/nodes/core/StructTypeNode.js

- getMembersLayout · function · L13-L27 — function getMembersLayout( members )
- StructTypeNode · class · L37-L151 — class StructTypeNode extends Node
- type · method · L39-L43 — static get type()
- constructor · method · L51-L79 — constructor( membersLayout, name = null )
- getLength · method · L87-L121 — getLength()
- getMemberType · method · L123-L129 — getMemberType( builder, name )
- getNodeType · method · L131-L137 — getNodeType( builder )
- setup · method · L139-L143 — setup( builder )
- generate · method · L145-L149 — generate( builder )
