# src/nodes/core/NodeFrame.js

- NodeFrame · class · L9-L304 — class NodeFrame
- constructor · method · L14-L109 — constructor()
- _getMaps · method · L120-L137 — _getMaps( referenceMap, nodeRef )
- updateBeforeNode · method · L147-L186 — updateBeforeNode( node )
- updateAfterNode · method · L196-L235 — updateAfterNode( node )
- updateNode · method · L245-L284 — updateNode( node )
- update · method · L290-L302 — update()
