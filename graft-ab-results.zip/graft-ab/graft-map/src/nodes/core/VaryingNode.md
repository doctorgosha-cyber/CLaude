# src/nodes/core/VaryingNode.js

- VaryingNode · class · L16-L184 — class VaryingNode extends Node
- type · method · L18-L22 — static get type()
- constructor · method · L30-L83 — constructor( node, name = null )
- setInterpolation · method · L92-L99 — setInterpolation( type, sampling = null )
- getHash · method · L101-L105 — getHash( builder )
- getNodeType · method · L107-L113 — getNodeType( builder )
- setupVarying · method · L121-L144 — setupVarying( builder )
- setup · method · L146-L152 — setup( builder )
- analyze · method · L154-L160 — analyze( builder )
- generate · method · L162-L182 — generate( builder )
- vertexStage · function · L207-L207 — vertexStage = ( node )
