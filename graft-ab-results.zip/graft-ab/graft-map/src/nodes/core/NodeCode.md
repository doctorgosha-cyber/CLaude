# src/nodes/core/NodeCode.js

- NodeCode · class · L7-L44 — class NodeCode
- constructor · method · L16-L42 — constructor( name, type, code = '' )
