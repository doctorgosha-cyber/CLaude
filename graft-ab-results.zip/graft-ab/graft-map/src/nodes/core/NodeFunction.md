# src/nodes/core/NodeFunction.js

- NodeFunction · class · L7-L64 — class NodeFunction
- constructor · method · L17-L49 — constructor( type, inputs, name = '', precision = '' )
- getCode · method · L58-L62 — getCode( /*name = this.name*/ )
