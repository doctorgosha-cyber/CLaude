# src/nodes/core/NodeParser.js

- NodeParser · class · L5-L20 — class NodeParser
- parseFunction · method · L14-L18 — parseFunction( /*source*/ )
