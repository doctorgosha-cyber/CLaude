# src/nodes/core/LightingModel.js

- LightingModel · class · L7-L75 — class LightingModel
- start · method · L16-L26 — start( builder )
- finish · method · L35-L35 — finish( /*builder*/ )
- direct · method · L45-L45 — direct( /*lightData, builder*/ )
- directRectArea · method · L55-L55 — directRectArea( /*lightData, builder*/ )
- indirect · method · L63-L63 — indirect( /*builder*/ )
- ambientOcclusion · method · L73-L73 — ambientOcclusion( /*input, stack, builder*/ )
