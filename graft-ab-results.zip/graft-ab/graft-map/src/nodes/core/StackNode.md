# src/nodes/core/StackNode.js

- StackNode · class · L11-L338 — class StackNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L24-L79 — constructor( parent = null )
- getNodeType · method · L81-L85 — getNodeType( builder )
- getMemberType · method · L87-L91 — getMemberType( builder, name )
- add · method · L99-L105 — add( node )
- If · method · L114-L121 — If( boolNode, method )
- ElseIf · method · L130-L140 — ElseIf( boolNode, method )
- Else · method · L148-L154 — Else( method )
- Switch · method · L163-L169 — Switch( expression )
- Case · method · L178-L232 — Case( ...params )
- Default · method · L240-L246 — Default( method )
- setup · method · L248-L276 — setup( builder )
- build · method · L278-L336 — build( builder, ...params )
