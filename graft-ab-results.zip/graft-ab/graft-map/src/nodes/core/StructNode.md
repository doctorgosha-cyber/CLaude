# src/nodes/core/StructNode.js

- StructNode · class · L25-L68 — class StructNode extends Node
- type · method · L27-L31 — static get type()
- constructor · method · L33-L42 — constructor( structLayoutNode, values )
- getNodeType · method · L44-L48 — getNodeType( builder )
- getMemberType · method · L50-L54 — getMemberType( builder, name )
- generate · method · L56-L66 — generate( builder )
- struct · function · L81-L120 — struct = ( membersLayout, name = null )
- struct · function · L85-L113 — struct = ( ...params )
