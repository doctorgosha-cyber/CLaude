# src/nodes/core/MRTNode.js

- getTextureIndex · function · L11-L25 — function getTextureIndex( textures, name )
- MRTNode · class · L40-L138 — class MRTNode extends OutputStructNode
- type · method · L42-L46 — static get type()
- constructor · method · L53-L75 — constructor( outputNodes )
- has · method · L83-L87 — has( name )
- get · method · L95-L99 — get( name )
- merge · method · L107-L113 — merge( mrtNode )
- setup · method · L115-L136 — setup( builder )
