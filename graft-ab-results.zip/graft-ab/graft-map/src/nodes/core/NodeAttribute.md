# src/nodes/core/NodeAttribute.js

- NodeAttribute · class · L7-L51 — class NodeAttribute
- constructor · method · L16-L49 — constructor( name, type, node = null )
