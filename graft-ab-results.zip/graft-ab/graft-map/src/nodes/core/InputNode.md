# src/nodes/core/InputNode.js

- InputNode · class · L9-L133 — class InputNode extends Node
- type · method · L11-L15 — static get type()
- constructor · method · L23-L51 — constructor( value, nodeType = null )
- getNodeType · method · L53-L63 — getNodeType( /*builder*/ )
- getInputType · method · L75-L79 — getInputType( builder )
- setPrecision · method · L89-L95 — setPrecision( precision )
- serialize · method · L97-L112 — serialize( data )
- deserialize · method · L114-L125 — deserialize( data )
- generate · method · L127-L131 — generate( /*builder, output*/ )
