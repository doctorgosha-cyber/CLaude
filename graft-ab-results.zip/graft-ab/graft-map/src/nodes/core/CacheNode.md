# src/nodes/core/CacheNode.js

- CacheNode · class · L11-L85 — class CacheNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L25-L53 — constructor( node, parent = true )
- getNodeType · method · L55-L68 — getNodeType( builder )
- build · method · L70-L83 — build( builder, ...params )
- cache · function · L98-L98 — cache = ( node, parent )
