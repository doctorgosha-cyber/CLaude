# src/nodes/core/IndexNode.js

- IndexNode · class · L17-L107 — class IndexNode extends Node
- type · method · L19-L23 — static get type()
- constructor · method · L30-L50 — constructor( scope )
- generate · method · L52-L105 — generate( builder )
