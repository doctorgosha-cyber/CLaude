# src/nodes/core/AssignNode.js

- AssignNode · class · L11-L186 — class AssignNode extends TempNode
- type · method · L13-L17 — static get type()
- constructor · method · L25-L52 — constructor( targetNode, sourceNode )
- hasDependencies · method · L60-L64 — hasDependencies()
- getNodeType · method · L66-L70 — getNodeType( builder, output )
- needsSplitAssign · method · L79-L94 — needsSplitAssign( builder )
- setup · method · L96-L107 — setup( builder )
- generate · method · L109-L184 — generate( builder, output )
