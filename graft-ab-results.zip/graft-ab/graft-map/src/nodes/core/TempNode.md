# src/nodes/core/TempNode.js

- TempNode · class · L11-L86 — class TempNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L24-L37 — constructor( nodeType = null )
- hasDependencies · method · L45-L49 — hasDependencies( builder )
- build · method · L51-L84 — build( builder, output )
