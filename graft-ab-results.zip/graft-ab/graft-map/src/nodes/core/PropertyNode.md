# src/nodes/core/PropertyNode.js

- PropertyNode · class · L16-L96 — class PropertyNode extends Node
- type · method · L18-L22 — static get type()
- constructor · method · L31-L69 — constructor( nodeType, name = null, varying = false )
- getHash · method · L71-L75 — getHash( builder )
- generate · method · L77-L94 — generate( builder )
- property · function · L109-L109 — property = ( type, name )
- varyingProperty · function · L120-L120 — varyingProperty = ( type, name )
