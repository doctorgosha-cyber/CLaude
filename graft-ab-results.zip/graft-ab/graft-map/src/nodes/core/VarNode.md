# src/nodes/core/VarNode.js

- VarNode · class · L14-L219 — class VarNode extends Node
- type · method · L16-L20 — static get type()
- constructor · method · L29-L92 — constructor( node, name = null, readOnly = false )
- setIntent · method · L106-L112 — setIntent( value )
- getIntent · method · L119-L123 — getIntent()
- getMemberType · method · L125-L129 — getMemberType( builder, name )
- getElementType · method · L131-L135 — getElementType( builder )
- getNodeType · method · L137-L141 — getNodeType( builder )
- getArrayCount · method · L143-L147 — getArrayCount( builder )
- build · method · L149-L166 — build( ...params )
- generate · method · L168-L217 — generate( builder )
- Var · function · L243-L243 — Var = ( node, name = null )
- Const · function · L254-L254 — Const = ( node, name = null )
- VarIntent · function · L268-L278 — VarIntent = ( node )
- temp · function · L296-L302 — temp = ( node )
