# src/nodes/core/UniformGroupNode.js

- UniformGroupNode · class · L16-L90 — class UniformGroupNode extends Node
- type · method · L18-L22 — static get type()
- constructor · method · L31-L68 — constructor( name, shared = false, order = 1 )
- serialize · method · L70-L78 — serialize( data )
- deserialize · method · L80-L88 — deserialize( data )
- uniformGroup · function · L102-L102 — uniformGroup = ( name )
- sharedUniformGroup · function · L113-L113 — sharedUniformGroup = ( name, order = 0 )
