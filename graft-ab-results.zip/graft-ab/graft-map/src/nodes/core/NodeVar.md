# src/nodes/core/NodeVar.js

- NodeVar · class · L7-L58 — class NodeVar
- constructor · method · L17-L56 — constructor( name, type, readOnly = false, count = null )
