# src/nodes/core/NodeUniform.js

- NodeUniform · class · L7-L89 — class NodeUniform
- constructor · method · L16-L48 — constructor( name, type, node )
- value · method · L55-L59 — get value()
- value · method · L61-L65 — set value( val )
- id · method · L72-L76 — get id()
- groupNode · method · L83-L87 — get groupNode()
