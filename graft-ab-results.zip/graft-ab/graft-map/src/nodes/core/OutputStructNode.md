# src/nodes/core/OutputStructNode.js

- OutputStructNode · class · L9-L91 — class OutputStructNode extends Node
- type · method · L11-L15 — static get type()
- constructor · method · L23-L43 — constructor( ...members )
- getNodeType · method · L45-L70 — getNodeType( builder )
- generate · method · L72-L89 — generate( builder )
