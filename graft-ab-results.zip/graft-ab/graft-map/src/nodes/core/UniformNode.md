# src/nodes/core/UniformNode.js

- UniformNode · class · L10-L213 — class UniformNode extends InputNode
- type · method · L12-L16 — static get type()
- constructor · method · L24-L54 — constructor( value, nodeType = null )
- setName · method · L62-L68 — setName( name )
- label · method · L77-L83 — label( name )
- setGroup · method · L91-L97 — setGroup( group )
- getGroup · method · L104-L108 — getGroup()
- getUniformHash · method · L117-L121 — getUniformHash( builder )
- onUpdate · method · L123-L141 — onUpdate( callback, updateType )
- getInputType · method · L143-L155 — getInputType( builder )
- generate · method · L157-L211 — generate( builder, output )
- uniform · function · L226-L235 — uniform = ( arg1, arg2 )
