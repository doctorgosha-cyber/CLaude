# src/nodes/core/StructType.js

- StructType · class · L1-L11 — class StructType
- constructor · method · L3-L9 — constructor( name, members )
