# src/nodes/core/BypassNode.js

- BypassNode · class · L15-L78 — class BypassNode extends Node
- type · method · L17-L21 — static get type()
- constructor · method · L29-L56 — constructor( outputNode, callNode )
- getNodeType · method · L58-L62 — getNodeType( builder )
- generate · method · L64-L76 — generate( builder )
