# src/nodes/core/SubBuildNode.js

- SubBuildNode · class · L12-L75 — class SubBuildNode extends Node
- type · method · L14-L18 — static get type()
- constructor · method · L20-L47 — constructor( node, name, nodeType = null )
- getNodeType · method · L49-L61 — getNodeType( builder )
- build · method · L63-L73 — build( builder, ...params )
- subBuild · function · L89-L89 — subBuild = ( node, name, type = null )
