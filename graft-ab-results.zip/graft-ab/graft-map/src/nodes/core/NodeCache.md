# src/nodes/core/NodeCache.js

- NodeCache · class · L7-L73 — class NodeCache
- constructor · method · L14-L39 — constructor( parent = null )
- getData · method · L47-L59 — getData( node )
- setData · method · L67-L71 — setData( node, data )
