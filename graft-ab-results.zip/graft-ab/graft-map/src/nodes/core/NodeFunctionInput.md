# src/nodes/core/NodeFunctionInput.js

- NodeFunctionInput · class · L4-L57 — class NodeFunctionInput
- constructor · method · L15-L55 — constructor( type, name, count = null, qualifier = '', isConst = false )
