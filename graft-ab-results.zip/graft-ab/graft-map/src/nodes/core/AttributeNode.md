# src/nodes/core/AttributeNode.js

- AttributeNode · class · L9-L154 — class AttributeNode extends Node
- type · method · L11-L15 — static get type()
- constructor · method · L23-L37 — constructor( attributeName, nodeType = null )
- getHash · method · L39-L43 — getHash( builder )
- getNodeType · method · L45-L69 — getNodeType( builder )
- setAttributeName · method · L79-L85 — setAttributeName( attributeName )
- getAttributeName · method · L95-L99 — getAttributeName( /*builder*/ )
- generate · method · L101-L134 — generate( builder )
- serialize · method · L136-L143 — serialize( data )
- deserialize · method · L145-L152 — deserialize( data )
- attribute · function · L167-L167 — attribute = ( name, nodeType = null )
