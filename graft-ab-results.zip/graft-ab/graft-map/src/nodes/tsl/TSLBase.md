# src/nodes/tsl/TSLBase.js

- addNodeElement · function · L29-L33 — function addNodeElement( name/*, nodeElement*/ )
