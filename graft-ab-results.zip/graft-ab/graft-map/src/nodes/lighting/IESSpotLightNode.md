# src/nodes/lighting/IESSpotLightNode.js

- IESSpotLightNode · class · L10-L47 — class IESSpotLightNode extends SpotLightNode
- type · method · L12-L16 — static get type()
- getSpotAttenuation · method · L25-L45 — getSpotAttenuation( builder, angleCosine )
