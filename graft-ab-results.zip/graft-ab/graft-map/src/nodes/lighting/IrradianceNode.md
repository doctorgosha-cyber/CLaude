# src/nodes/lighting/IrradianceNode.js

- IrradianceNode · class · L10-L42 — class IrradianceNode extends LightingNode
- type · method · L12-L16 — static get type()
- constructor · method · L23-L34 — constructor( node )
- setup · method · L36-L40 — setup( builder )
