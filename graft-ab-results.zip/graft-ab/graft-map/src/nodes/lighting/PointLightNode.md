# src/nodes/lighting/PointLightNode.js

- directPointLight · function · L7-L22 — directPointLight = ( { color, lightVector, cutoffDistance, decayExponent } )
- PointLightNode · class · L29-L100 — class PointLightNode extends AnalyticLightNode
- type · method · L31-L35 — static get type()
- constructor · method · L42-L60 — constructor( light = null )
- update · method · L67-L76 — update( frame )
- setupShadowNode · method · L83-L87 — setupShadowNode()
- setupDirect · method · L89-L98 — setupDirect( builder )
