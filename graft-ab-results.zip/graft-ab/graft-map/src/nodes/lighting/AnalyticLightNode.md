# src/nodes/lighting/AnalyticLightNode.js

- AnalyticLightNode · class · L16-L254 — class AnalyticLightNode extends LightingNode
- type · method · L18-L22 — static get type()
- constructor · method · L29-L99 — constructor( light = null )
- getHash · method · L101-L105 — getHash()
- getLightVector · method · L114-L118 — getLightVector( builder )
- setupDirect · method · L127-L127 — setupDirect( /*builder*/ )
- setupDirectRectArea · method · L136-L136 — setupDirectRectArea( /*builder*/ )
- setupShadowNode · method · L144-L148 — setupShadowNode()
- setupShadow · method · L157-L193 — setupShadow( builder )
- setup · method · L202-L237 — setup( builder )
- update · method · L246-L252 — update( /*frame*/ )
