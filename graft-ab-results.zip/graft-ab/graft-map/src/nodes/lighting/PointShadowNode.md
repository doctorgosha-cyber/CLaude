# src/nodes/lighting/PointShadowNode.js

- PointShadowNode · class · L166-L293 — class PointShadowNode extends ShadowNode
- type · method · L168-L172 — static get type()
- constructor · method · L180-L184 — constructor( light, shadow = null )
- getShadowFilterFn · method · L193-L197 — getShadowFilterFn( type )
- setupShadowCoord · method · L206-L210 — setupShadowCoord( builder, shadowPosition )
- setupShadowFilter · method · L225-L229 — setupShadowFilter( builder, { filterFn, shadowTexture, depthTexture, shadowCoord, shadow } )
- renderShadow · method · L237-L291 — renderShadow( frame )
- pointShadow · function · L306-L306 — pointShadow = ( light, shadow )
