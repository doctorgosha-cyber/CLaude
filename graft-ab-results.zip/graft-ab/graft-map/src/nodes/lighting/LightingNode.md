# src/nodes/lighting/LightingNode.js

- LightingNode · class · L8-L34 — class LightingNode extends Node
- type · method · L10-L14 — static get type()
- constructor · method · L19-L32 — constructor()
