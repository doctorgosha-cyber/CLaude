# src/nodes/lighting/AmbientLightNode.js

- AmbientLightNode · class · L8-L33 — class AmbientLightNode extends AnalyticLightNode
- type · method · L10-L14 — static get type()
- constructor · method · L21-L25 — constructor( light = null )
- setup · method · L27-L31 — setup( { context } )
