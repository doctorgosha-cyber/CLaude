# src/nodes/lighting/LightingContextNode.js

- LightingContextNode · class · L11-L111 — class LightingContextNode extends ContextNode
- type · method · L13-L17 — static get type()
- constructor · method · L27-L57 — constructor( lightsNode, lightingModel = null, backdropNode = null, backdropAlphaNode = null )
- getContext · method · L72-L100 — getContext()
- setup · method · L102-L109 — setup( builder )
