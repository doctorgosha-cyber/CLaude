# src/nodes/lighting/AONode.js

- AONode · class · L10-L43 — class AONode extends LightingNode
- type · method · L12-L16 — static get type()
- constructor · method · L23-L35 — constructor( aoNode = null )
- setup · method · L37-L41 — setup( builder )
