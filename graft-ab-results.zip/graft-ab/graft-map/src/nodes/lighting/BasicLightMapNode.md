# src/nodes/lighting/BasicLightMapNode.js

- BasicLightMapNode · class · L11-L47 — class BasicLightMapNode extends LightingNode
- type · method · L13-L17 — static get type()
- constructor · method · L24-L35 — constructor( lightMapNode = null )
- setup · method · L37-L45 — setup( builder )
