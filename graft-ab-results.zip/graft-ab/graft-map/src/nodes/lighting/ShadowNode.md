# src/nodes/lighting/ShadowNode.js

- getShadowRenderObjectFunction · function · L45-L86 — getShadowRenderObjectFunction = ( renderer, shadow, shadowType, useVelocity )
- ShadowNode · class · L190-L731 — class ShadowNode extends ShadowBaseNode
- type · method · L192-L196 — static get type()
- constructor · method · L204-L291 — constructor( light, shadow = null )
- setupShadowFilter · method · L304-L316 — setupShadowFilter( builder, { filterFn, depthTexture, shadowCoord, shadow, depthLayer } )
- setupShadowCoord · method · L325-L370 — setupShadowCoord( builder, shadowPosition )
- getShadowFilterFn · method · L378-L382 — getShadowFilterFn( type )
- setupRenderTarget · method · L385-L398 — setupRenderTarget( shadow, builder )
- setupShadow · method · L406-L519 — setupShadow( builder )
- setup · method · L528-L560 — setup( builder )
- renderShadow · method · L570-L581 — renderShadow( frame )
- updateShadow · method · L588-L637 — updateShadow( frame )
- vsmPass · method · L644-L660 — vsmPass( renderer )
- dispose · method · L665-L692 — dispose()
- updateBefore · method · L699-L729 — updateBefore( frame )
- shadow · function · L744-L744 — shadow = ( light, shadow )
