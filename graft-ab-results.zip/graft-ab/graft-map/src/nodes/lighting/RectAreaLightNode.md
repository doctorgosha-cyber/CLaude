# src/nodes/lighting/RectAreaLightNode.js

- RectAreaLightNode · class · L21-L131 — class RectAreaLightNode extends AnalyticLightNode
- type · method · L23-L27 — static get type()
- constructor · method · L34-L61 — constructor( light = null )
- update · method · L68-L87 — update( frame )
- setupDirectRectArea · method · L89-L118 — setupDirectRectArea( builder )
- setLTC · method · L125-L129 — static setLTC( ltc )
