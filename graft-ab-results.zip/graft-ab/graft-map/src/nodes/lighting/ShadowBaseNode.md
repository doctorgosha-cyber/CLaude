# src/nodes/lighting/ShadowBaseNode.js

- ShadowBaseNode · class · L15-L71 — class ShadowBaseNode extends Node
- type · method · L17-L21 — static get type()
- constructor · method · L28-L56 — constructor( light )
- setupShadowPosition · method · L63-L69 — setupShadowPosition( { context, material } )
