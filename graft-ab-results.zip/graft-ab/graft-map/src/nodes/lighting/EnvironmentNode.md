# src/nodes/lighting/EnvironmentNode.js

- EnvironmentNode · class · L21-L104 — class EnvironmentNode extends LightingNode
- type · method · L23-L27 — static get type()
- constructor · method · L34-L46 — constructor( envNode = null )
- setup · method · L48-L102 — setup( builder )
- createRadianceContext · function · L108-L136 — createRadianceContext = ( roughnessNode, normalViewNode )
- createIrradianceContext · function · L138-L153 — createIrradianceContext = ( normalWorldNode )
