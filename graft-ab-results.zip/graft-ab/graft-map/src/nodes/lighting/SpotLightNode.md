# src/nodes/lighting/SpotLightNode.js

- SpotLightNode · class · L14-L166 — class SpotLightNode extends AnalyticLightNode
- type · method · L16-L20 — static get type()
- constructor · method · L27-L66 — constructor( light = null )
- update · method · L73-L85 — update( frame )
- getSpotAttenuation · method · L94-L100 — getSpotAttenuation( builder, angleCosine )
- getLightCoord · method · L102-L117 — getLightCoord( builder )
- setupDirect · method · L119-L164 — setupDirect( builder )
