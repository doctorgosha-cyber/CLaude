# src/nodes/lighting/BasicEnvironmentNode.js

- BasicEnvironmentNode · class · L12-L47 — class BasicEnvironmentNode extends LightingNode
- type · method · L14-L18 — static get type()
- constructor · method · L25-L37 — constructor( envNode = null )
- setup · method · L39-L45 — setup( builder )
