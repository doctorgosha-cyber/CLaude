# src/nodes/lighting/ShadowFilterNode.js

- depthCompare · function · L49-L61 — depthCompare = ( uv, compare )
- depthCompare · function · L110-L122 — depthCompare = ( uv, compare )
- linearShadowDistance · function · L228-L239 — linearShadowDistance = ( light )
- getShadowMaterial · function · L253-L274 — getShadowMaterial = ( light )
