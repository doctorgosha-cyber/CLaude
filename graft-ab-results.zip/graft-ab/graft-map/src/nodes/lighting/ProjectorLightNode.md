# src/nodes/lighting/ProjectorLightNode.js

- ProjectorLightNode · class · L22-L89 — class ProjectorLightNode extends SpotLightNode
- type · method · L24-L28 — static get type()
- update · method · L30-L56 — update( frame )
- getSpotAttenuation · method · L64-L87 — getSpotAttenuation( builder )
