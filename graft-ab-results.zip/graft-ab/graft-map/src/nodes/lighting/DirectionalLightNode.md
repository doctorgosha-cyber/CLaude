# src/nodes/lighting/DirectionalLightNode.js

- DirectionalLightNode · class · L9-L37 — class DirectionalLightNode extends AnalyticLightNode
- type · method · L11-L15 — static get type()
- constructor · method · L22-L26 — constructor( light = null )
- setupDirect · method · L28-L35 — setupDirect()
