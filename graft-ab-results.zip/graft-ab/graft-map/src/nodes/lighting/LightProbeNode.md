# src/nodes/lighting/LightProbeNode.js

- LightProbeNode · class · L12-L71 — class LightProbeNode extends AnalyticLightNode
- type · method · L14-L18 — static get type()
- constructor · method · L25-L40 — constructor( light = null )
- update · method · L47-L61 — update( frame )
- setup · method · L63-L69 — setup( builder )
