# src/nodes/lighting/HemisphereLightNode.js

- HemisphereLightNode · class · L15-L85 — class HemisphereLightNode extends AnalyticLightNode
- type · method · L17-L21 — static get type()
- constructor · method · L28-L53 — constructor( light = null )
- update · method · L60-L70 — update( frame )
- setup · method · L72-L83 — setup( builder )
