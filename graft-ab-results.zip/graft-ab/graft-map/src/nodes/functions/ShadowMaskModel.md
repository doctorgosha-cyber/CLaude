# src/nodes/functions/ShadowMaskModel.js

- ShadowMaskModel · class · L10-L56 — class ShadowMaskModel extends LightingModel
- constructor · method · L15-L26 — constructor()
- direct · method · L33-L41 — direct( { lightNode } )
- finish · method · L48-L54 — finish( { context } )
