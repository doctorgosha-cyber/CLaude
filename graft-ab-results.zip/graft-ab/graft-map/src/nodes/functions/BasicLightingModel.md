# src/nodes/functions/BasicLightingModel.js

- BasicLightingModel · class · L15-L97 — class BasicLightingModel extends LightingModel
- constructor · method · L20-L24 — constructor()
- indirect · method · L31-L57 — indirect( { context } )
- finish · method · L64-L95 — finish( builder )
