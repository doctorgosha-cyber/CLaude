# src/nodes/functions/PhysicalLightingModel.js

- Fresnel0ToIor · function · L200-L205 — Fresnel0ToIor = ( fresnel0 )
- IorToFresnel0 · function · L208-L212 — IorToFresnel0 = ( transmittedIor, incidentIor )
- evalSensitivity · function · L217-L233 — evalSensitivity = ( OPD, shift )
- PhysicalLightingModel · class · L350-L794 — class PhysicalLightingModel extends LightingModel
- constructor · method · L362-L470 — constructor( clearcoat = false, sheen = false, iridescence = false, anisotropy = false, transmission = false, dispersion = false )
- start · method · L478-L545 — start( builder )
- computeMultiscattering · method · L551-L570 — computeMultiscattering( singleScatter, multiScatter, specularF90 )
- direct · method · L578-L602 — direct( { lightDirection, lightColor, reflectedLight }, /* builder */ )
- directRectArea · method · L611-L641 — directRectArea( { lightColor, lightPosition, halfWidth, halfHeight, reflectedLight, ltc_1, ltc_2 }, /* builder */ )
- indirect · method · L648-L654 — indirect( builder )
- indirectDiffuse · method · L661-L667 — indirectDiffuse( builder )
- indirectSpecular · method · L674-L723 — indirectSpecular( builder )
- ambientOcclusion · method · L730-L756 — ambientOcclusion( builder )
- finish · method · L763-L792 — finish( { context } )
