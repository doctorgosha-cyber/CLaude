# src/nodes/functions/BSDF/BRDF_Lambert.js

_No extracted symbols in this file._
