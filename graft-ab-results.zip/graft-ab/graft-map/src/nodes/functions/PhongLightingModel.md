# src/nodes/functions/PhongLightingModel.js

- G_BlinnPhong_Implicit · function · L10-L10 — G_BlinnPhong_Implicit = ()
- PhongLightingModel · class · L38-L97 — class PhongLightingModel extends BasicLightingModel
- constructor · method · L45-L59 — constructor( specular = true )
- direct · method · L67-L80 — direct( { lightDirection, lightColor, reflectedLight } )
- indirect · method · L87-L95 — indirect( builder )
