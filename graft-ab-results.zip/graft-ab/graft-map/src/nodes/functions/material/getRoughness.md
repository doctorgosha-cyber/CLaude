# src/nodes/functions/material/getRoughness.js

_No extracted symbols in this file._
