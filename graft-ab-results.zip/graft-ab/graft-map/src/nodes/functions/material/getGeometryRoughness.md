# src/nodes/functions/material/getGeometryRoughness.js

_No extracted symbols in this file._
