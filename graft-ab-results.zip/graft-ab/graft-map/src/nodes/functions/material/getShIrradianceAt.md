# src/nodes/functions/material/getShIrradianceAt.js

_No extracted symbols in this file._
