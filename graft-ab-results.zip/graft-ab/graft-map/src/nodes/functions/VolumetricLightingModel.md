# src/nodes/functions/VolumetricLightingModel.js

- VolumetricLightingModel · class · L23-L181 — class VolumetricLightingModel extends LightingModel
- constructor · method · L25-L29 — constructor()
- start · method · L31-L123 — start( builder )
- scatteringLight · method · L125-L143 — scatteringLight( lightColor, builder )
- direct · method · L145-L158 — direct( { lightNode, lightColor }, builder )
- directRectArea · method · L160-L173 — directRectArea( { lightColor, lightPosition, halfWidth, halfHeight }, builder )
- finish · method · L175-L179 — finish( builder )
