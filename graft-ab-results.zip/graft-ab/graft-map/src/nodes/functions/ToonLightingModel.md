# src/nodes/functions/ToonLightingModel.js

- ToonLightingModel · class · L36-L68 — class ToonLightingModel extends LightingModel
- direct · method · L45-L51 — direct( { lightDirection, lightColor, reflectedLight }, builder )
- indirect · method · L58-L66 — indirect( builder )
