# src/nodes/display/ViewportSharedTextureNode.js

- ViewportSharedTextureNode · class · L16-L48 — class ViewportSharedTextureNode extends ViewportTextureNode
- type · method · L18-L22 — static get type()
- constructor · method · L30-L40 — constructor( uvNode = screenUV, levelNode = null )
- updateReference · method · L42-L46 — updateReference()
