# src/nodes/display/PosterizeNode.js

- PosterizeNode · class · L10-L52 — class PosterizeNode extends TempNode
- type · method · L12-L16 — static get type()
- constructor · method · L24-L42 — constructor( sourceNode, stepsNode )
- setup · method · L44-L50 — setup()
