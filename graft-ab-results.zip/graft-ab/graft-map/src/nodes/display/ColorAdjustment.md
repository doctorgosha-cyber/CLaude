# src/nodes/display/ColorAdjustment.js

- luminance · function · L87-L90 — luminance = ( color, luminanceCoefficients = vec3( ColorManagement.getLuminanceCoefficients( new Vector3() ) ) )
