# src/nodes/display/BumpMapNode.js

- sampleTexture · function · L14-L14 — sampleTexture = ( callback )
- BumpMapNode · class · L56-L104 — class BumpMapNode extends TempNode
- type · method · L58-L62 — static get type()
- constructor · method · L70-L89 — constructor( textureNode, scaleNode = null )
- setup · method · L91-L102 — setup()
