# src/nodes/display/ViewportDepthTextureNode.js

- ViewportDepthTextureNode · class · L16-L42 — class ViewportDepthTextureNode extends ViewportTextureNode
- type · method · L18-L22 — static get type()
- constructor · method · L30-L40 — constructor( uvNode = screenUV, levelNode = null )
