# src/nodes/display/ViewportDepthNode.js

- ViewportDepthNode · class · L14-L133 — class ViewportDepthNode extends Node
- type · method · L16-L20 — static get type()
- constructor · method · L28-L62 — constructor( scope, valueNode = null )
- generate · method · L64-L76 — generate( builder )
- setup · method · L78-L131 — setup( { camera } )
- viewZToOrthographicDepth · function · L153-L153 — viewZToOrthographicDepth = ( viewZ, near, far )
- orthographicDepthToViewZ · function · L165-L165 — orthographicDepthToViewZ = ( depth, near, far )
- viewZToPerspectiveDepth · function · L179-L179 — viewZToPerspectiveDepth = ( viewZ, near, far )
- perspectiveDepthToViewZ · function · L191-L191 — perspectiveDepthToViewZ = ( depth, near, far )
- viewZToLogarithmicDepth · function · L203-L236 — viewZToLogarithmicDepth = ( viewZ, near, far )
- logarithmicDepthToViewZ · function · L248-L256 — logarithmicDepthToViewZ = ( depth, near, far )
