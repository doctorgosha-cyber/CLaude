# src/nodes/display/RenderOutputNode.js

- RenderOutputNode · class · L30-L108 — class RenderOutputNode extends TempNode
- type · method · L32-L36 — static get type()
- constructor · method · L45-L79 — constructor( colorNode, toneMapping, outputColorSpace )
- setup · method · L81-L106 — setup( { context } )
- renderOutput · function · L122-L122 — renderOutput = ( color, toneMapping = null, outputColorSpace = null )
