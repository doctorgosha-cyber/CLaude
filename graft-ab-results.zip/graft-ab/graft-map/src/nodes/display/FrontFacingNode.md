# src/nodes/display/FrontFacingNode.js

- FrontFacingNode · class · L11-L59 — class FrontFacingNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L22-L35 — constructor()
- generate · method · L37-L57 — generate( builder )
