# src/nodes/display/NormalMapNode.js

- NormalMapNode · class · L19-L104 — class NormalMapNode extends TempNode
- type · method · L21-L25 — static get type()
- constructor · method · L33-L60 — constructor( node, scaleNode = null )
- setup · method · L62-L102 — setup( { material } )
