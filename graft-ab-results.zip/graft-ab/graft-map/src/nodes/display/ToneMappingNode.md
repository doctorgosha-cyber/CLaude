# src/nodes/display/ToneMappingNode.js

- ToneMappingNode · class · L13-L96 — class ToneMappingNode extends TempNode
- type · method · L15-L19 — static get type()
- constructor · method · L28-L55 — constructor( toneMapping, exposureNode = toneMappingExposure, colorNode = null )
- customCacheKey · method · L63-L67 — customCacheKey()
- setup · method · L69-L94 — setup( builder )
- toneMapping · function · L110-L110 — toneMapping = ( mapping, exposure, color )
