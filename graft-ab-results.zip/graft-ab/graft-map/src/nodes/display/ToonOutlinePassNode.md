# src/nodes/display/ToonOutlinePassNode.js

- ToonOutlinePassNode · class · L25-L167 — class ToonOutlinePassNode extends PassNode
- type · method · L27-L31 — static get type()
- constructor · method · L42-L75 — constructor( scene, camera, colorNode, thicknessNode, alphaNode )
- updateBefore · method · L77-L108 — updateBefore( frame )
- _createMaterial · method · L116-L141 — _createMaterial()
- _getOutlineMaterial · method · L151-L165 — _getOutlineMaterial( originalMaterial )
- toonOutlinePass · function · L183-L183 — toonOutlinePass = ( scene, camera, color = new Color( 0, 0, 0 ), thickness = 0.003, alpha = 1 )
