# src/nodes/display/ColorSpaceNode.js

- ColorSpaceNode · class · L18-L125 — class ColorSpaceNode extends TempNode
- type · method · L20-L24 — static get type()
- constructor · method · L33-L58 — constructor( colorNode, source, target )
- resolveColorSpace · method · L69-L83 — resolveColorSpace( builder, colorSpace )
- setup · method · L85-L123 — setup( builder )
- workingToColorSpace · function · L138-L138 — workingToColorSpace = ( node, targetColorSpace )
- colorSpaceToWorking · function · L149-L149 — colorSpaceToWorking = ( node, sourceColorSpace )
- convertColorSpace · function · L161-L161 — convertColorSpace = ( node, sourceColorSpace, targetColorSpace )
