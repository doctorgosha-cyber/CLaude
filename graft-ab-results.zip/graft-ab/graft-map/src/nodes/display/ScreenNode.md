# src/nodes/display/ScreenNode.js

- ScreenNode · class · L18-L180 — class ScreenNode extends Node
- type · method · L20-L24 — static get type()
- constructor · method · L31-L56 — constructor( scope )
- getNodeType · method · L63-L68 — getNodeType()
- getUpdateType · method · L75-L89 — getUpdateType()
- update · method · L97-L130 — update( { renderer } )
- setup · method · L132-L154 — setup( /*builder*/ )
- generate · method · L156-L178 — generate( builder )
