# src/nodes/display/ViewportTextureNode.js

- ViewportTextureNode · class · L21-L172 — class ViewportTextureNode extends TextureNode
- type · method · L23-L27 — static get type()
- constructor · method · L36-L99 — constructor( uvNode = screenUV, levelNode = null, framebufferTexture = null )
- getFrameBufferTexture · method · L101-L121 — getFrameBufferTexture( reference = null )
- updateBefore · method · L123-L161 — updateBefore( frame )
- clone · method · L163-L170 — clone()
