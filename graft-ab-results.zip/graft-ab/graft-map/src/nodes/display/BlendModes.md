# src/nodes/display/BlendModes.js

- burn · function · L184-L189 — burn = ( ...params )
- dodge · function · L199-L204 — dodge = ( ...params )
- screen · function · L214-L219 — screen = ( ...params )
- overlay · function · L229-L234 — overlay = ( ...params )
