# src/nodes/parsers/GLSLNodeParser.js

- GLSLNodeParser · class · L9-L23 — class GLSLNodeParser extends NodeParser
- parseFunction · method · L17-L21 — parseFunction( source )
