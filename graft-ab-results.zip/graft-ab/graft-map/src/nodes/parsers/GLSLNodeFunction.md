# src/nodes/parsers/GLSLNodeFunction.js

- parse · function · L9-L102 — parse = ( source )
- GLSLNodeFunction · class · L109-L166 — class GLSLNodeFunction extends NodeFunction
- constructor · method · L116-L126 — constructor( source )
- getCode · method · L134-L164 — getCode( name = this.name )
