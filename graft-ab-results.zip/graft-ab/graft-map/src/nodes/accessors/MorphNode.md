# src/nodes/accessors/MorphNode.js

- getEntry · function · L33-L157 — function getEntry( geometry )
- disposeTexture · function · L141-L149 — function disposeTexture()
- MorphNode · class · L165-L298 — class MorphNode extends Node
- type · method · L167-L171 — static get type()
- constructor · method · L178-L203 — constructor( mesh )
- setup · method · L210-L275 — setup( builder )
- update · method · L282-L296 — update( /*frame*/ )
