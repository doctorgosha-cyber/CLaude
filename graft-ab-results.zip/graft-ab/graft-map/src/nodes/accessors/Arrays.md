# src/nodes/accessors/Arrays.js

- attributeArray · function · L15-L36 — attributeArray = ( count, type = 'float' )
- instancedArray · function · L47-L68 — instancedArray = ( count, type = 'float' )
