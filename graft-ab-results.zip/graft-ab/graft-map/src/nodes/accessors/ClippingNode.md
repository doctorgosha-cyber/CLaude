# src/nodes/accessors/ClippingNode.js

- ClippingNode · class · L18-L221 — class ClippingNode extends Node
- type · method · L20-L24 — static get type()
- constructor · method · L32-L44 — constructor( scope = ClippingNode.DEFAULT )
- setup · method · L52-L75 — setup( builder )
- setupAlphaToCoverage · method · L84-L140 — setupAlphaToCoverage( intersectionPlanes, unionPlanes )
- setupDefault · method · L149-L188 — setupDefault( intersectionPlanes, unionPlanes )
- setupHardwareClipping · method · L197-L219 — setupHardwareClipping( unionPlanes, builder )
- clipping · function · L236-L236 — clipping = ()
- clippingAlpha · function · L245-L245 — clippingAlpha = ()
- hardwareClipping · function · L254-L254 — hardwareClipping = ()
