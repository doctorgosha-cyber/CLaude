# src/nodes/accessors/InstanceNode.js

- InstanceNode · class · L23-L210 — class InstanceNode extends Node
- type · method · L25-L29 — static get type()
- constructor · method · L38-L101 — constructor( count, instanceMatrix, instanceColor = null )
- setup · method · L110-L187 — setup( builder )
- update · method · L194-L208 — update( /*frame*/ )
