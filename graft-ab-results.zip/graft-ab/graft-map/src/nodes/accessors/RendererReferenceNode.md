# src/nodes/accessors/RendererReferenceNode.js

- RendererReferenceNode · class · L16-L64 — class RendererReferenceNode extends ReferenceBaseNode
- type · method · L18-L22 — static get type()
- constructor · method · L32-L47 — constructor( property, inputType, renderer = null )
- updateReference · method · L56-L62 — updateReference( state )
- rendererReference · function · L79-L79 — rendererReference = ( name, type, renderer = null )
