# src/nodes/accessors/SkinningNode.js

- SkinningNode · class · L25-L291 — class SkinningNode extends Node
- type · method · L27-L31 — static get type()
- constructor · method · L38-L116 — constructor( skinnedMesh )
- getSkinnedPosition · method · L125-L147 — getSkinnedPosition( boneMatrices = this.boneMatricesNode, position = this.positionNode )
- getSkinnedNormal · method · L156-L178 — getSkinnedNormal( boneMatrices = this.boneMatricesNode, normal = normalLocal )
- getPreviousSkinnedPosition · method · L186-L200 — getPreviousSkinnedPosition( builder )
- needsPreviousBoneMatrices · method · L209-L215 — needsPreviousBoneMatrices( builder )
- setup · method · L223-L253 — setup( builder )
- generate · method · L262-L270 — generate( builder, output )
- update · method · L277-L289 — update( frame )
- skinning · function · L303-L303 — skinning = ( skinnedMesh )
- computeSkinning · function · L314-L327 — computeSkinning = ( skinnedMesh, toPosition = null )
