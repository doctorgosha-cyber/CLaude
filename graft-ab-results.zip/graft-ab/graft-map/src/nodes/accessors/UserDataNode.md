# src/nodes/accessors/UserDataNode.js

- UserDataNode · class · L18-L63 — class UserDataNode extends ReferenceNode
- type · method · L20-L24 — static get type()
- constructor · method · L33-L46 — constructor( property, inputType, userData = null )
- updateReference · method · L55-L61 — updateReference( state )
- userData · function · L77-L77 — userData = ( name, inputType, userData )
