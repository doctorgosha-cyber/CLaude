# src/nodes/accessors/Object3DNode.js

- Object3DNode · class · L23-L199 — class Object3DNode extends Node
- type · method · L25-L29 — static get type()
- constructor · method · L37-L71 — constructor( scope, object3d = null )
- getNodeType · method · L78-L96 — getNodeType()
- update · method · L103-L152 — update( frame )
- generate · method · L161-L181 — generate( builder )
- serialize · method · L183-L189 — serialize( data )
- deserialize · method · L191-L197 — deserialize( data )
