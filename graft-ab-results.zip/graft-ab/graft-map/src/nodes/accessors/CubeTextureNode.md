# src/nodes/accessors/CubeTextureNode.js

- CubeTextureNode · class · L17-L130 — class CubeTextureNode extends TextureNode
- type · method · L19-L23 — static get type()
- constructor · method · L33-L46 — constructor( value, uvNode = null, levelNode = null, biasNode = null )
- getInputType · method · L54-L58 — getInputType( /*builder*/ )
- getDefaultUV · method · L65-L85 — getDefaultUV()
- setUpdateMatrix · method · L93-L93 — setUpdateMatrix( /*updateMatrix*/ )
- setupUV · method · L103-L115 — setupUV( builder, uvNode )
- generateUV · method · L124-L128 — generateUV( builder, cubeUV )
- cubeTexture · function · L158-L179 — cubeTexture = ( value = EmptyTexture, uvNode = null, levelNode = null, biasNode = null )
- uniformCubeTexture · function · L189-L189 — uniformCubeTexture = ( value = EmptyTexture )
