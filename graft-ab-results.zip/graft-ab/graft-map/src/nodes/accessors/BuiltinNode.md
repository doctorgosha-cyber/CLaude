# src/nodes/accessors/BuiltinNode.js

- BuiltinNode · class · L10-L51 — class BuiltinNode extends Node
- constructor · method · L17-L37 — constructor( name )
- generate · method · L45-L49 — generate( /* builder */ )
