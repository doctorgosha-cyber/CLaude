# src/nodes/accessors/ModelNode.js

- ModelNode · class · L17-L50 — class ModelNode extends Object3DNode
- type · method · L19-L23 — static get type()
- constructor · method · L30-L34 — constructor( scope )
- update · method · L42-L48 — update( frame )
