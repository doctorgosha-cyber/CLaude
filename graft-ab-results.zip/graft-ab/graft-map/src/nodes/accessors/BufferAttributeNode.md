# src/nodes/accessors/BufferAttributeNode.js

- BufferAttributeNode · class · L31-L283 — class BufferAttributeNode extends InputNode
- type · method · L33-L37 — static get type()
- constructor · method · L47-L125 — constructor( value, bufferType = null, bufferStride = 0, bufferOffset = 0 )
- getHash · method · L134-L156 — getHash( builder )
- getNodeType · method · L165-L175 — getNodeType( builder )
- setup · method · L184-L202 — setup( builder )
- generate · method · L210-L235 — generate( builder )
- getInputType · method · L243-L247 — getInputType( /*builder*/ )
- setUsage · method · L255-L267 — setUsage( value )
- setInstanced · method · L275-L281 — setInstanced( value )
- bufferAttribute · function · L298-L298 — bufferAttribute = ( array, type = null, stride = 0, offset = 0 )
- dynamicBufferAttribute · function · L312-L312 — dynamicBufferAttribute = ( array, type = null, stride = 0, offset = 0 )
- instancedBufferAttribute · function · L325-L325 — instancedBufferAttribute = ( array, type = null, stride = 0, offset = 0 )
- instancedDynamicBufferAttribute · function · L338-L338 — instancedDynamicBufferAttribute = ( array, type = null, stride = 0, offset = 0 )
