# src/nodes/accessors/AccessorsUtils.js

- parallaxUV · function · L34-L34 — parallaxUV = ( uv, scale )
