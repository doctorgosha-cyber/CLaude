# src/nodes/accessors/MaterialReferenceNode.js

- MaterialReferenceNode · class · L15-L70 — class MaterialReferenceNode extends ReferenceNode
- type · method · L17-L21 — static get type()
- constructor · method · L31-L53 — constructor( property, inputType, material = null )
- updateReference · method · L62-L68 — updateReference( state )
- materialReference · function · L85-L85 — materialReference = ( name, type, material = null )
