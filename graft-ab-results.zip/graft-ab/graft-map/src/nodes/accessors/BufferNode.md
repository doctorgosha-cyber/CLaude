# src/nodes/accessors/BufferNode.js

- BufferNode · class · L18-L87 — class BufferNode extends UniformNode
- type · method · L20-L24 — static get type()
- constructor · method · L33-L61 — constructor( value, bufferType, bufferCount = 0 )
- getElementType · method · L69-L73 — getElementType( builder )
- getInputType · method · L81-L85 — getInputType( /*builder*/ )
- buffer · function · L101-L101 — buffer = ( value, type, count )
