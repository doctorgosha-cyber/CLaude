# src/nodes/accessors/Lights.js

- getLightData · function · L9-L19 — function getLightData( light )
- lightShadowMatrix · function · L29-L45 — function lightShadowMatrix( light )
- lightProjectionUV · function · L57-L64 — function lightProjectionUV( light, position = positionWorld )
- lightPosition · function · L74-L80 — function lightPosition( light )
- lightTargetPosition · function · L90-L96 — function lightTargetPosition( light )
- lightViewPosition · function · L106-L119 — function lightViewPosition( light )
- lightTargetDirection · function · L129-L129 — lightTargetDirection = ( light )
