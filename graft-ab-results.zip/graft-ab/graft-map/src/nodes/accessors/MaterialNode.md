# src/nodes/accessors/MaterialNode.js

- MaterialNode · class · L21-L405 — class MaterialNode extends Node
- type · method · L23-L27 — static get type()
- constructor · method · L34-L45 — constructor( scope )
- getCache · method · L54-L68 — getCache( property, type )
- getFloat · method · L76-L80 — getFloat( property )
- getColor · method · L88-L92 — getColor( property )
- getTexture · method · L100-L104 — getTexture( property )
- setup · method · L113-L403 — setup( builder )
