# src/nodes/accessors/PointUVNode.js

- PointUVNode · class · L13-L45 — class PointUVNode extends Node
- type · method · L15-L19 — static get type()
- constructor · method · L24-L37 — constructor()
- generate · method · L39-L43 — generate( /*builder*/ )
