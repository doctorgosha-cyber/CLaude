# src/nodes/accessors/MaterialProperties.js

_No extracted symbols in this file._
