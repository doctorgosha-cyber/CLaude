# src/nodes/accessors/VertexColorNode.js

- VertexColorNode · class · L10-L98 — class VertexColorNode extends AttributeNode
- type · method · L12-L16 — static get type()
- constructor · method · L23-L44 — constructor( index )
- getAttributeName · method · L52-L58 — getAttributeName( /*builder*/ )
- generate · method · L60-L80 — generate( builder )
- serialize · method · L82-L88 — serialize( data )
- deserialize · method · L90-L96 — deserialize( data )
- vertexColor · function · L110-L110 — vertexColor = ( index = 0 )
