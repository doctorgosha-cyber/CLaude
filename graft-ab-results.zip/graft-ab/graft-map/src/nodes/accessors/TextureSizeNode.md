# src/nodes/accessors/TextureSizeNode.js

- TextureSizeNode · class · L11-L64 — class TextureSizeNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L25-L53 — constructor( textureNode, levelNode = null )
- generate · method · L55-L62 — generate( builder, output )
