# src/nodes/accessors/Texture3DNode.js

- Texture3DNode · class · L56-L172 — class Texture3DNode extends TextureNode
- type · method · L58-L62 — static get type()
- constructor · method · L71-L84 — constructor( value, uvNode = null, levelNode = null )
- getInputType · method · L92-L96 — getInputType( /*builder*/ )
- getDefaultUV · method · L104-L108 — getDefaultUV()
- setUpdateMatrix · method · L116-L116 — setUpdateMatrix( /*value*/ )
- setupUV · method · L125-L145 — setupUV( builder, uvNode )
- generateUV · method · L154-L158 — generateUV( builder, uvNode )
- normal · method · L166-L170 — normal( uvNode )
