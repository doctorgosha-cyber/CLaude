# src/nodes/accessors/UniformArrayNode.js

- UniformArrayElementNode · class · L12-L51 — class UniformArrayElementNode extends ArrayElementNode
- type · method · L14-L18 — static get type()
- constructor · method · L26-L39 — constructor( uniformArrayNode, indexNode )
- generate · method · L41-L49 — generate( builder )
- UniformArrayNode · class · L70-L335 — class UniformArrayNode extends BufferNode
- type · method · L72-L76 — static get type()
- constructor · method · L84-L129 — constructor( value, elementType = null )
- getNodeType · method · L138-L142 — getNodeType( /*builder*/ )
- getElementType · method · L150-L154 — getElementType()
- getPaddedType · method · L161-L187 — getPaddedType()
- update · method · L195-L293 — update( /*frame*/ )
- setup · method · L301-L320 — setup( builder )
- element · method · L329-L333 — element( indexNode )
- uniformArray · function · L348-L348 — uniformArray = ( values, nodeType )
