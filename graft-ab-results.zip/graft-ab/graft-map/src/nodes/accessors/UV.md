# src/nodes/accessors/UV.js

- uv · function · L11-L11 — uv = ( index = 0 )
