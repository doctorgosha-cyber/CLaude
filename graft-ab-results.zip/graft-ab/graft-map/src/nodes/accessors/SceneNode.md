# src/nodes/accessors/SceneNode.js

- SceneNode · class · L22-L114 — class SceneNode extends Node
- type · method · L24-L28 — static get type()
- constructor · method · L36-L55 — constructor( scope = SceneNode.BACKGROUND_BLURRINESS, scene = null )
- setup · method · L64-L112 — setup( builder )
