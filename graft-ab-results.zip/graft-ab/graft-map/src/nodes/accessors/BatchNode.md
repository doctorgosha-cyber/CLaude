# src/nodes/accessors/BatchNode.js

- BatchNode · class · L18-L151 — class BatchNode extends Node
- type · method · L20-L24 — static get type()
- constructor · method · L31-L50 — constructor( batchMesh )
- setup · method · L59-L149 — setup( builder )
