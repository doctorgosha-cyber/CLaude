# src/nodes/accessors/VelocityNode.js

- VelocityNode · class · L24-L182 — class VelocityNode extends TempNode
- type · method · L26-L30 — static get type()
- constructor · method · L35-L87 — constructor()
- setProjectionMatrix · method · L94-L98 — setProjectionMatrix( projectionMatrix )
- update · method · L105-L145 — update( { frameId, camera, object } )
- updateAfter · method · L152-L156 — updateAfter( { object } )
- setup · method · L164-L180 — setup( /*builder*/ )
- getData · function · L184-L197 — function getData( object )
- getPreviousMatrix · function · L199-L214 — function getPreviousMatrix( object, index = 0 )
