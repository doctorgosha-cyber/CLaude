# src/nodes/accessors/TextureBicubic.js

- w0 · function · L11-L11 — w0 = ( a )
- w1 · function · L13-L13 — w1 = ( a )
- w2 · function · L15-L15 — w2 = ( a )
- w3 · function · L17-L17 — w3 = ( a )
- g0 · function · L19-L19 — g0 = ( a )
- g1 · function · L21-L21 — g1 = ( a )
- h0 · function · L24-L24 — h0 = ( a )
- h1 · function · L26-L26 — h1 = ( a )
- bicubic · function · L28-L53 — bicubic = ( textureNode, texelSize, lod )
