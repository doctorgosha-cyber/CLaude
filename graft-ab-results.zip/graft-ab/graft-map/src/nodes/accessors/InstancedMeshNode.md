# src/nodes/accessors/InstancedMeshNode.js

- InstancedMeshNode · class · L10-L38 — class InstancedMeshNode extends InstanceNode
- type · method · L12-L16 — static get type()
- constructor · method · L23-L36 — constructor( instancedMesh )
