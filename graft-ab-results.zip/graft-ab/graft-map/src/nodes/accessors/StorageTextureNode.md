# src/nodes/accessors/StorageTextureNode.js

- StorageTextureNode · class · L36-L207 — class StorageTextureNode extends TextureNode
- type · method · L38-L42 — static get type()
- constructor · method · L51-L80 — constructor( value, uvNode, storeNode = null )
- getInputType · method · L88-L92 — getInputType( /*builder*/ )
- setup · method · L94-L103 — setup( builder )
- setAccess · method · L111-L116 — setAccess( value )
- generate · method · L126-L142 — generate( builder, output )
- toReadWrite · method · L149-L153 — toReadWrite()
- toReadOnly · method · L160-L164 — toReadOnly()
- toWriteOnly · method · L171-L175 — toWriteOnly()
- generateStore · method · L182-L197 — generateStore( builder )
- clone · method · L199-L205 — clone()
- textureStore · function · L234-L242 — textureStore = ( value, uvNode, storeNode )
