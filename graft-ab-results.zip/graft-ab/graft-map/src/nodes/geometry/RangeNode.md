# src/nodes/geometry/RangeNode.js

- RangeNode · class · L26-L159 — class RangeNode extends Node
- type · method · L28-L32 — static get type()
- constructor · method · L40-L60 — constructor( minNode = float(), maxNode = float() )
- getVectorLength · method · L68-L75 — getVectorLength( builder )
- getNodeType · method · L83-L87 — getNodeType( builder )
- setup · method · L89-L157 — setup( builder )
