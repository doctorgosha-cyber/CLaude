# src/nodes/procedural/Checker.js

_No extracted symbols in this file._
