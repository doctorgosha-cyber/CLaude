# src/nodes/fog/Fog.js

- getViewZNode · function · L16-L30 — function getViewZNode( builder )
- rangeFog · function · L92-L97 — function rangeFog( color, near, far )
- densityFog · function · L108-L113 — function densityFog( color, density )
