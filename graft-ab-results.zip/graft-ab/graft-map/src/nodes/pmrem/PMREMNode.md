# src/nodes/pmrem/PMREMNode.js

- _generateCubeUVSize · function · L21-L31 — function _generateCubeUVSize( imageHeight )
- _getPMREMFromTexture · function · L42-L89 — function _getPMREMFromTexture( texture, renderer, generator )
- _getCache · function · L100-L113 — function _getCache( renderer )
- PMREMNode · class · L126-L343 — class PMREMNode extends TempNode
- type · method · L128-L132 — static get type()
- constructor · method · L141-L228 — constructor( value, uvNode = null, levelNode = null )
- value · method · L230-L235 — set value( value )
- value · method · L242-L246 — get value()
- updateFromTexture · method · L253-L262 — updateFromTexture( texture )
- updateBefore · method · L264-L293 — updateBefore( frame )
- setup · method · L295-L333 — setup( builder )
- dispose · method · L335-L341 — dispose()
- isCubeMapReady · function · L354-L370 — function isCubeMapReady( image )
- isEquirectangularMapReady · function · L379-L385 — function isEquirectangularMapReady( image )
