# src/nodes/utils/JoinNode.js

- JoinNode · class · L10-L112 — class JoinNode extends TempNode
- type · method · L12-L16 — static get type()
- constructor · method · L24-L35 — constructor( nodes = [], nodeType = null )
- getNodeType · method · L44-L54 — getNodeType( builder )
- generate · method · L56-L110 — generate( builder, output )
