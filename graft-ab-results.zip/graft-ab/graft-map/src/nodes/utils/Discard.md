# src/nodes/utils/Discard.js

- Discard · function · L13-L13 — Discard = ( conditional )
- Return · function · L22-L22 — Return = ()
