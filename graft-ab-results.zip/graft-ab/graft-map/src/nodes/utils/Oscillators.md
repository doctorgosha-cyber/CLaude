# src/nodes/utils/Oscillators.js

- oscSine · function · L11-L11 — oscSine = ( t = time )
- oscSquare · function · L21-L21 — oscSquare = ( t = time )
- oscTriangle · function · L31-L31 — oscTriangle = ( t = time )
- oscSawtooth · function · L41-L41 — oscSawtooth = ( t = time )
