# src/nodes/utils/SetNode.js

- SetNode · class · L15-L106 — class SetNode extends TempNode
- type · method · L17-L21 — static get type()
- constructor · method · L30-L55 — constructor( sourceNode, components, targetNode )
- getNodeType · method · L63-L67 — getNodeType( builder )
- generate · method · L69-L104 — generate( builder )
