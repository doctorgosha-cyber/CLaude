# src/nodes/utils/MemberNode.js

- MemberNode · class · L9-L66 — class MemberNode extends Node
- type · method · L11-L15 — static get type()
- constructor · method · L23-L50 — constructor( node, property )
- getNodeType · method · L52-L56 — getNodeType( builder )
- generate · method · L58-L64 — generate( builder )
