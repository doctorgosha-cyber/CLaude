# src/nodes/utils/Packing.js

- directionToColor · function · L11-L11 — directionToColor = ( node )
- colorToDirection · function · L21-L21 — colorToDirection = ( node )
