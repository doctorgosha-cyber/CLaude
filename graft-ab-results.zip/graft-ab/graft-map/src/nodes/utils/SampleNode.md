# src/nodes/utils/SampleNode.js

- SampleNode · class · L10-L70 — class SampleNode extends Node
- type · method · L19-L23 — static get type()
- constructor · method · L30-L45 — constructor( callback )
- setup · method · L52-L56 — setup()
- sample · method · L64-L68 — sample( uv )
- sample · function · L81-L81 — sample = ( callback )
