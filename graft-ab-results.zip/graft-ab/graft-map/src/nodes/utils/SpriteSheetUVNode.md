# src/nodes/utils/SpriteSheetUVNode.js

- SpriteSheetUVNode · class · L16-L76 — class SpriteSheetUVNode extends Node
- type · method · L18-L22 — static get type()
- constructor · method · L31-L56 — constructor( countNode, uvNode = uv(), frameNode = float( 0 ) )
- setup · method · L58-L74 — setup()
