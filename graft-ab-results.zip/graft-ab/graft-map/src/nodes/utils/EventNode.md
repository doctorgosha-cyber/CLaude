# src/nodes/utils/EventNode.js

- EventNode · class · L10-L49 — class EventNode extends Node
- type · method · L12-L16 — static get type()
- constructor · method · L24-L41 — constructor( eventType, callback )
- update · method · L43-L47 — update( frame )
- createEvent · function · L63-L63 — createEvent = ( type, callback )
- OnObjectUpdate · function · L73-L73 — OnObjectUpdate = ( callback )
- OnMaterialUpdate · function · L83-L83 — OnMaterialUpdate = ( callback )
