# src/nodes/utils/RemapNode.js

- RemapNode · class · L11-L92 — class RemapNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L28-L78 — constructor( node, inLowNode, inHighNode, outLowNode = float( 0 ), outHighNode = float( 1 ) )
- setup · method · L80-L90 — setup()
