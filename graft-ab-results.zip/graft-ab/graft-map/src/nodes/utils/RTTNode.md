# src/nodes/utils/RTTNode.js

- RTTNode · class · L22-L244 — class RTTNode extends TextureNode
- type · method · L24-L28 — static get type()
- constructor · method · L38-L134 — constructor( node, width = null, height = null, options = { type: HalfFloatType } )
- autoResize · method · L143-L147 — get autoResize()
- setup · method · L149-L157 — setup( builder )
- setSize · method · L165-L177 — setSize( width, height )
- setPixelRatio · method · L184-L190 — setPixelRatio( pixelRatio )
- updateBefore · method · L192-L232 — updateBefore( { renderer } )
- clone · method · L234-L242 — clone()
- rtt · function · L259-L259 — rtt = ( node, ...params )
- convertToTexture · function · L272-L279 — convertToTexture = ( node, ...params )
