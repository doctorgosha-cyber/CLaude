# src/nodes/utils/LoopNode.js

- LoopNode · class · L41-L323 — class LoopNode extends Node
- type · method · L43-L47 — static get type()
- constructor · method · L54-L60 — constructor( params = [] )
- getVarName · method · L69-L73 — getVarName( index )
- getProperties · method · L81-L119 — getProperties( builder )
- getNodeType · method · L127-L133 — getNodeType( builder )
- setup · method · L135-L141 — setup( builder )
- generate · method · L143-L321 — generate( builder )
- deltaOperator · function · L235-L235 — deltaOperator = ()
- Loop · function · L335-L335 — Loop = ( ...params )
- Continue · function · L344-L344 — Continue = ()
- Break · function · L353-L353 — Break = ()
