# src/nodes/utils/FlipNode.js

- FlipNode · class · L19-L104 — class FlipNode extends TempNode
- type · method · L21-L25 — static get type()
- constructor · method · L33-L51 — constructor( sourceNode, components )
- getNodeType · method · L59-L63 — getNodeType( builder )
- generate · method · L65-L102 — generate( builder )
