# src/nodes/utils/ConvertNode.js

- ConvertNode · class · L10-L98 — class ConvertNode extends Node
- type · method · L12-L16 — static get type()
- constructor · method · L24-L42 — constructor( node, convertTo )
- getNodeType · method · L51-L69 — getNodeType( builder )
- serialize · method · L71-L77 — serialize( data )
- deserialize · method · L79-L85 — deserialize( data )
- generate · method · L87-L96 — generate( builder, output )
