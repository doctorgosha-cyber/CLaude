# src/nodes/utils/TriplanarTextures.js

- triplanarTexture · function · L65-L65 — triplanarTexture = ( ...params )
