# src/nodes/utils/FunctionOverloadingNode.js

- FunctionOverloadingNode · class · L11-L138 — class FunctionOverloadingNode extends Node
- type · method · L13-L17 — static get type()
- constructor · method · L25-L59 — constructor( functionNodes = [], ...parametersNodes )
- getNodeType · method · L68-L72 — getNodeType()
- setup · method · L74-L136 — setup( builder )
- overloadingFn · function · L152-L152 — overloadingFn = ( functionNodes )
