# src/nodes/utils/StorageArrayElementNode.js

- StorageArrayElementNode · class · L15-L130 — class StorageArrayElementNode extends ArrayElementNode
- type · method · L17-L21 — static get type()
- constructor · method · L29-L42 — constructor( storageBufferNode, indexNode )
- storageBufferNode · method · L50-L54 — set storageBufferNode( value )
- storageBufferNode · method · L56-L60 — get storageBufferNode()
- getMemberType · method · L62-L74 — getMemberType( builder, name )
- setup · method · L76-L90 — setup( builder )
- generate · method · L92-L128 — generate( builder, output )
