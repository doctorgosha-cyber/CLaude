# src/nodes/utils/MaxMipLevelNode.js

- MaxMipLevelNode · class · L15-L91 — class MaxMipLevelNode extends UniformNode
- type · method · L17-L21 — static get type()
- constructor · method · L28-L49 — constructor( textureNode )
- textureNode · method · L57-L61 — get textureNode()
- texture · method · L69-L73 — get texture()
- update · method · L75-L89 — update()
