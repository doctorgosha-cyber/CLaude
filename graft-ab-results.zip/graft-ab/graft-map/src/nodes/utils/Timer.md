# src/nodes/utils/Timer.js

- timerLocal · function · L38-L43 — timerLocal = ( timeScale = 1 )
- timerGlobal · function · L53-L58 — timerGlobal = ( timeScale = 1 )
- timerDelta · function · L68-L73 — timerDelta = ( timeScale = 1 )
