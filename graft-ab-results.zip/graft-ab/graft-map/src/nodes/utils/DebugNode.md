# src/nodes/utils/DebugNode.js

- DebugNode · class · L4-L67 — class DebugNode extends TempNode
- type · method · L6-L10 — static get type()
- constructor · method · L12-L19 — constructor( node, callback = null )
- getNodeType · method · L21-L25 — getNodeType( builder )
- setup · method · L27-L31 — setup( builder )
- analyze · method · L33-L37 — analyze( builder )
- generate · method · L39-L65 — generate( builder )
- debug · function · L80-L80 — debug = ( node, callback = null )
