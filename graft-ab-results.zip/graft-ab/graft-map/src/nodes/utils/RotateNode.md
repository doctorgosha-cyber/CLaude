# src/nodes/utils/RotateNode.js

- RotateNode · class · L10-L89 — class RotateNode extends TempNode
- type · method · L12-L16 — static get type()
- constructor · method · L25-L44 — constructor( positionNode, rotationNode )
- getNodeType · method · L52-L56 — getNodeType( builder )
- setup · method · L58-L87 — setup( builder )
