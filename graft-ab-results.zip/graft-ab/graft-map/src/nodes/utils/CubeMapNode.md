# src/nodes/utils/CubeMapNode.js

- CubeMapNode · class · L17-L161 — class CubeMapNode extends TempNode
- type · method · L19-L23 — static get type()
- constructor · method · L30-L80 — constructor( envNode )
- updateBefore · method · L82-L151 — updateBefore( frame )
- setup · method · L153-L159 — setup( builder )
- isEquirectangularMapReady · function · L173-L179 — function isEquirectangularMapReady( image )
- onTextureDispose · function · L189-L205 — function onTextureDispose( event )
- mapTextureMapping · function · L215-L227 — function mapTextureMapping( texture, mapping )
