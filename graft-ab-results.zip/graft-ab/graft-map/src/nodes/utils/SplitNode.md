# src/nodes/utils/SplitNode.js

- SplitNode · class · L17-L166 — class SplitNode extends Node
- type · method · L19-L23 — static get type()
- constructor · method · L31-L58 — constructor( node, components = 'x' )
- getVectorLength · method · L65-L77 — getVectorLength()
- getComponentType · method · L85-L89 — getComponentType( builder )
- getNodeType · method · L97-L101 — getNodeType( builder )
- generate · method · L103-L148 — generate( builder, output )
- serialize · method · L150-L156 — serialize( data )
- deserialize · method · L158-L164 — deserialize( data )
