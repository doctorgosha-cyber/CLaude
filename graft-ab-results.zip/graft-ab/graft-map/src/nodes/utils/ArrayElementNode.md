# src/nodes/utils/ArrayElementNode.js

- ArrayElementNode · class · L9-L75 — class ArrayElementNode extends Node
- type · method · L11-L15 — static get type()
- constructor · method · L23-L50 — constructor( node, indexNode )
- getNodeType · method · L58-L62 — getNodeType( builder )
- generate · method · L64-L73 — generate( builder )
