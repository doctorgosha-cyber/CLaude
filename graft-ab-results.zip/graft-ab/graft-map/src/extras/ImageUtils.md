# src/extras/ImageUtils.js

- ImageUtils · class · L11-L135 — class ImageUtils
- getDataURL · method · L20-L65 — static getDataURL( image, type = 'image/png' )
- sRGBToLinear · method · L73-L133 — static sRGBToLinear( image )
