# src/extras/DataUtils.js

- _generateTables · function · L7-L140 — function _generateTables()
- toHalfFloat · function · L149-L160 — function toHalfFloat( val )
- fromHalfFloat · function · L169-L175 — function fromHalfFloat( val )
- DataUtils · class · L182-L210 — class DataUtils
- toHalfFloat · method · L191-L195 — static toHalfFloat( val )
- fromHalfFloat · method · L204-L208 — static fromHalfFloat( val )
