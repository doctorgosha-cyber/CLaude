# src/extras/Controls.js

- Controls · class · L9-L117 — class Controls extends EventDispatcher
- constructor · method · L17-L75 — constructor( object, domElement = null )
- connect · method · L83-L96 — connect( element )
- disconnect · method · L101-L101 — disconnect()
- dispose · method · L107-L107 — dispose()
- update · method · L115-L115 — update( /* delta */ )
