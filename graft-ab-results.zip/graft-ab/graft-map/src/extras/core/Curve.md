# src/extras/core/Curve.js

- Curve · class · L12-L513 — class Curve
- constructor · method · L17-L56 — constructor()
- getPoint · method · L67-L71 — getPoint( /* t, optionalTarget */ )
- getPointAt · method · L82-L87 — getPointAt( u, optionalTarget )
- getPoints · method · L96-L108 — getPoints( divisions = 5 )
- getSpacedPoints · method · L120-L132 — getSpacedPoints( divisions = 5 )
- getLength · method · L139-L144 — getLength()
- getLengths · method · L152-L183 — getLengths( divisions = this.arcLengthDivisions )
- updateArcLengths · method · L191-L196 — updateArcLengths()
- getUtoTmapping · method · L207-L280 — getUtoTmapping( u, distance = null )
- getTangent · method · L292-L312 — getTangent( t, optionalTarget )
- getTangentAt · method · L322-L327 — getTangentAt( u, optionalTarget )
- computeFrenetFrames · method · L337-L449 — computeFrenetFrames( segments, closed = false )
- clone · method · L456-L460 — clone()
- copy · method · L468-L474 — copy( source )
- toJSON · method · L482-L497 — toJSON()
- fromJSON · method · L505-L511 — fromJSON( json )
