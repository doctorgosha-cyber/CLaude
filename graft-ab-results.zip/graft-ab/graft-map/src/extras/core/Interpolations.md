# src/extras/core/Interpolations.js

- CatmullRom · function · L13-L21 — function CatmullRom( t, p0, p1, p2, p3 )
- QuadraticBezierP0 · function · L25-L30 — function QuadraticBezierP0( t, p )
- QuadraticBezierP1 · function · L32-L36 — function QuadraticBezierP1( t, p )
- QuadraticBezierP2 · function · L38-L42 — function QuadraticBezierP2( t, p )
- QuadraticBezier · function · L53-L58 — function QuadraticBezier( t, p0, p1, p2 )
- CubicBezierP0 · function · L62-L67 — function CubicBezierP0( t, p )
- CubicBezierP1 · function · L69-L74 — function CubicBezierP1( t, p )
- CubicBezierP2 · function · L76-L80 — function CubicBezierP2( t, p )
- CubicBezierP3 · function · L82-L86 — function CubicBezierP3( t, p )
- CubicBezier · function · L98-L103 — function CubicBezier( t, p0, p1, p2, p3 )
