# src/extras/core/Shape.js

- Shape · class · L35-L162 — class Shape extends Path
- constructor · method · L42-L65 — constructor( points )
- getPointsHoles · method · L74-L86 — getPointsHoles( divisions )
- extractPoints · method · L97-L106 — extractPoints( divisions )
- copy · method · L108-L124 — copy( source )
- toJSON · method · L126-L142 — toJSON()
- fromJSON · method · L144-L160 — fromJSON( json )
