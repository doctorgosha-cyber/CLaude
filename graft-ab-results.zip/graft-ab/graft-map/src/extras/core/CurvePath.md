# src/extras/core/CurvePath.js

- CurvePath · class · L10-L293 — class CurvePath extends Curve
- constructor · method · L15-L38 — constructor()
- add · method · L45-L49 — add( curve )
- closePath · method · L56-L71 — closePath()
- getPoint · method · L81-L120 — getPoint( t, optionalTarget )
- getLength · method · L122-L131 — getLength()
- updateArcLengths · method · L133-L141 — updateArcLengths()
- getCurveLengths · method · L148-L177 — getCurveLengths()
- getSpacedPoints · method · L179-L197 — getSpacedPoints( divisions = 40 )
- getPoints · method · L199-L235 — getPoints( divisions = 12 )
- copy · method · L237-L255 — copy( source )
- toJSON · method · L257-L273 — toJSON()
- fromJSON · method · L275-L291 — fromJSON( json )
