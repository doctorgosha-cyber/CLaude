# src/extras/core/Path.js

- Path · class · L31-L326 — class Path extends CurvePath
- constructor · method · L38-L57 — constructor( points )
- setFromPoints · method · L66-L78 — setFromPoints( points )
- moveTo · method · L87-L93 — moveTo( x, y )
- lineTo · method · L103-L112 — lineTo( x, y )
- quadraticCurveTo · method · L124-L138 — quadraticCurveTo( aCPx, aCPy, aX, aY )
- bezierCurveTo · method · L152-L167 — bezierCurveTo( aCP1x, aCP1y, aCP2x, aCP2y, aX, aY )
- splineThru · method · L176-L187 — splineThru( pts )
- arc · method · L201-L211 — arc( aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise )
- absarc · method · L224-L230 — absarc( aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise )
- ellipse · method · L246-L255 — ellipse( aX, aY, xRadius, yRadius, aStartAngle, aEndAngle, aClockwise, aRotation )
- absellipse · method · L270-L294 — absellipse( aX, aY, xRadius, yRadius, aStartAngle, aEndAngle, aClockwise, aRotation )
- copy · method · L296-L304 — copy( source )
- toJSON · method · L306-L314 — toJSON()
- fromJSON · method · L316-L324 — fromJSON( json )
