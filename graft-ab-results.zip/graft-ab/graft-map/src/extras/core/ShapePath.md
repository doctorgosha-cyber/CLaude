# src/extras/core/ShapePath.js

- ShapePath · class · L10-L364 — class ShapePath
- constructor · method · L15-L42 — constructor()
- moveTo · method · L51-L59 — moveTo( x, y )
- lineTo · method · L69-L75 — lineTo( x, y )
- quadraticCurveTo · method · L87-L93 — quadraticCurveTo( aCPx, aCPy, aX, aY )
- bezierCurveTo · method · L107-L113 — bezierCurveTo( aCP1x, aCP1y, aCP2x, aCP2y, aX, aY )
- splineThru · method · L122-L128 — splineThru( pts )
- toShapes · method · L137-L362 — toShapes( isCCW )
- toShapesNoHoles · function · L139-L156 — function toShapesNoHoles( inSubpaths )
- isPointInsidePolygon · function · L158-L216 — function isPointInsidePolygon( inPt, inPolygon )
