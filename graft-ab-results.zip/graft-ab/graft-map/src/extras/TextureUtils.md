# src/extras/TextureUtils.js

- contain · function · L12-L36 — function contain( texture, aspect )
- cover · function · L47-L71 — function cover( texture, aspect )
- fill · function · L79-L89 — function fill( texture )
- getByteLength · function · L100-L197 — function getByteLength( width, height, format, type )
- getTextureTypeByteLength · function · L199-L224 — function getTextureTypeByteLength( type )
- TextureUtils · class · L231-L290 — class TextureUtils
- contain · method · L242-L246 — static contain( texture, aspect )
- cover · method · L257-L261 — static cover( texture, aspect )
- fill · method · L269-L273 — static fill( texture )
- getByteLength · method · L284-L288 — static getByteLength( width, height, format, type )
