# src/extras/Earcut.js

- Earcut · class · L3-L20 — class Earcut
- triangulate · method · L14-L18 — static triangulate( data, holeIndices, dim = 2 )
