# src/extras/ShapeUtils.js

- ShapeUtils · class · L8-L89 — class ShapeUtils
- area · method · L16-L29 — static area( contour )
- isClockWise · method · L37-L41 — static isClockWise( pts )
- triangulateShape · method · L50-L87 — static triangulateShape( contour, holes )
- removeDupEndPts · function · L91-L101 — function removeDupEndPts( points )
- addContour · function · L103-L112 — function addContour( vertices, contour )
