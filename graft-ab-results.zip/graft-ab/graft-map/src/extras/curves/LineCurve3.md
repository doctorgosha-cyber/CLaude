# src/extras/curves/LineCurve3.js

- LineCurve3 · class · L9-L126 — class LineCurve3 extends Curve
- constructor · method · L17-L46 — constructor( v1 = new Vector3(), v2 = new Vector3() )
- getPoint · method · L55-L72 — getPoint( t, optionalTarget = new Vector3() )
- getPointAt · method · L75-L79 — getPointAt( u, optionalTarget )
- getTangent · method · L81-L85 — getTangent( t, optionalTarget = new Vector3() )
- getTangentAt · method · L87-L91 — getTangentAt( u, optionalTarget )
- copy · method · L93-L102 — copy( source )
- toJSON · method · L104-L113 — toJSON()
- fromJSON · method · L115-L124 — fromJSON( json )
