# src/extras/curves/QuadraticBezierCurve.js

- QuadraticBezierCurve · class · L26-L131 — class QuadraticBezierCurve extends Curve
- constructor · method · L35-L71 — constructor( v0 = new Vector2(), v1 = new Vector2(), v2 = new Vector2() )
- getPoint · method · L80-L93 — getPoint( t, optionalTarget = new Vector2() )
- copy · method · L95-L105 — copy( source )
- toJSON · method · L107-L117 — toJSON()
- fromJSON · method · L119-L129 — fromJSON( json )
