# src/extras/curves/CatmullRomCurve3.js

- CubicPoly · function · L4-L76 — function CubicPoly()
- init · function · L35-L42 — function init( x0, x1, t0, t1 )
- CatmullRomCurve3 · class · L109-L324 — class CatmullRomCurve3 extends Curve
- constructor · method · L119-L165 — constructor( points = [], closed = false, curveType = 'centripetal', tension = 0.5 )
- getPoint · method · L174-L258 — getPoint( t, optionalTarget = new Vector3() )
- copy · method · L260-L280 — copy( source )
- toJSON · method · L282-L301 — toJSON()
- fromJSON · method · L303-L322 — fromJSON( json )
