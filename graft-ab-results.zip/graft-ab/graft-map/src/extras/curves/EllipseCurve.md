# src/extras/curves/EllipseCurve.js

- EllipseCurve · class · L27-L256 — class EllipseCurve extends Curve
- constructor · method · L41-L122 — constructor( aX = 0, aY = 0, xRadius = 1, yRadius = 1, aStartAngle = 0, aEndAngle = Math.PI * 2, aClockwise = false, aRotation = 0 )
- getPoint · method · L131-L191 — getPoint( t, optionalTarget = new Vector2() )
- copy · method · L193-L212 — copy( source )
- toJSON · method · L214-L233 — toJSON()
- fromJSON · method · L235-L254 — fromJSON( json )
