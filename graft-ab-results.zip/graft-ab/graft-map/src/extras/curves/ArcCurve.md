# src/extras/curves/ArcCurve.js

- ArcCurve · class · L8-L37 — class ArcCurve extends EllipseCurve
- constructor · method · L20-L35 — constructor( aX, aY, aRadius, aStartAngle, aEndAngle, aClockwise )
