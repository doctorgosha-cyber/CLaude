# src/extras/curves/SplineCurve.js

- SplineCurve · class · L29-L143 — class SplineCurve extends Curve
- constructor · method · L36-L58 — constructor( points = [] )
- getPoint · method · L67-L89 — getPoint( t, optionalTarget = new Vector2() )
- copy · method · L91-L107 — copy( source )
- toJSON · method · L109-L124 — toJSON()
- fromJSON · method · L126-L141 — fromJSON( json )
