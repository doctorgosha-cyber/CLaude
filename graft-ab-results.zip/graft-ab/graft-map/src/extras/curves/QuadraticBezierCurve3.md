# src/extras/curves/QuadraticBezierCurve3.js

- QuadraticBezierCurve3 · class · L10-L116 — class QuadraticBezierCurve3 extends Curve
- constructor · method · L19-L55 — constructor( v0 = new Vector3(), v1 = new Vector3(), v2 = new Vector3() )
- getPoint · method · L64-L78 — getPoint( t, optionalTarget = new Vector3() )
- copy · method · L80-L90 — copy( source )
- toJSON · method · L92-L102 — toJSON()
- fromJSON · method · L104-L114 — fromJSON( json )
