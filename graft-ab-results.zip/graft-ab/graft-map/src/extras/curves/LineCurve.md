# src/extras/curves/LineCurve.js

- LineCurve · class · L9-L126 — class LineCurve extends Curve
- constructor · method · L17-L46 — constructor( v1 = new Vector2(), v2 = new Vector2() )
- getPoint · method · L55-L72 — getPoint( t, optionalTarget = new Vector2() )
- getPointAt · method · L75-L79 — getPointAt( u, optionalTarget )
- getTangent · method · L81-L85 — getTangent( t, optionalTarget = new Vector2() )
- getTangentAt · method · L87-L91 — getTangentAt( u, optionalTarget )
- copy · method · L93-L102 — copy( source )
- toJSON · method · L104-L113 — toJSON()
- fromJSON · method · L115-L124 — fromJSON( json )
