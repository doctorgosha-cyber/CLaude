# src/extras/curves/CubicBezierCurve3.js

- CubicBezierCurve3 · class · L10-L127 — class CubicBezierCurve3 extends Curve
- constructor · method · L20-L63 — constructor( v0 = new Vector3(), v1 = new Vector3(), v2 = new Vector3(), v3 = new Vector3() )
- getPoint · method · L72-L86 — getPoint( t, optionalTarget = new Vector3() )
- copy · method · L88-L99 — copy( source )
- toJSON · method · L101-L112 — toJSON()
- fromJSON · method · L114-L125 — fromJSON( json )
