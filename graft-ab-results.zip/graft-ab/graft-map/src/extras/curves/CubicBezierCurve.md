# src/extras/curves/CubicBezierCurve.js

- CubicBezierCurve · class · L27-L143 — class CubicBezierCurve extends Curve
- constructor · method · L37-L80 — constructor( v0 = new Vector2(), v1 = new Vector2(), v2 = new Vector2(), v3 = new Vector2() )
- getPoint · method · L89-L102 — getPoint( t, optionalTarget = new Vector2() )
- copy · method · L104-L115 — copy( source )
- toJSON · method · L117-L128 — toJSON()
- fromJSON · method · L130-L141 — fromJSON( json )
