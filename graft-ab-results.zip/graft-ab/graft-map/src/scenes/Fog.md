# src/scenes/Fog.js

- Fog · class · L12-L96 — class Fog
- constructor · method · L21-L65 — constructor( color, near = 1, far = 1000 )
- clone · method · L72-L76 — clone()
- toJSON · method · L84-L94 — toJSON( /* meta */ )
