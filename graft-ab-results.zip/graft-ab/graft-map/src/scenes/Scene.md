# src/scenes/Scene.js

- Scene · class · L10-L163 — class Scene extends Object3D
- constructor · method · L15-L121 — constructor()
- copy · method · L123-L144 — copy( source, recursive )
- toJSON · method · L146-L161 — toJSON( meta )
