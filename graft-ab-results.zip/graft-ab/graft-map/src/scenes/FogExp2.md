# src/scenes/FogExp2.js

- FogExp2 · class · L13-L84 — class FogExp2
- constructor · method · L21-L54 — constructor( color, density = 0.00025 )
- clone · method · L61-L65 — clone()
- toJSON · method · L73-L82 — toJSON( /* meta */ )
