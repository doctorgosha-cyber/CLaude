# src/math/FrustumArray.js

- FrustumArray · class · L12-L256 — class FrustumArray
- constructor · method · L18-L28 — constructor()
- intersectsObject · method · L38-L71 — intersectsObject( object, cameraArray )
- intersectsSprite · method · L81-L114 — intersectsSprite( sprite, cameraArray )
- intersectsSphere · method · L124-L157 — intersectsSphere( sphere, cameraArray )
- intersectsBox · method · L167-L200 — intersectsBox( box, cameraArray )
- containsPoint · method · L210-L243 — containsPoint( point, cameraArray )
- clone · method · L250-L254 — clone()
