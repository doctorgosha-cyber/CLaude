# src/math/Cylindrical.js

- Cylindrical · class · L5-L118 — class Cylindrical
- constructor · method · L14-L40 — constructor( radius = 1, theta = 0, y = 0 )
- set · method · L50-L58 — set( radius, theta, y )
- copy · method · L66-L74 — copy( other )
- setFromVector3 · method · L83-L87 — setFromVector3( v )
- setFromCartesianCoords · method · L97-L105 — setFromCartesianCoords( x, y, z )
- clone · method · L112-L116 — clone()
