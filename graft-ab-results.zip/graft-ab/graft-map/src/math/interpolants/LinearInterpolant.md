# src/math/interpolants/LinearInterpolant.js

- LinearInterpolant · class · L8-L48 — class LinearInterpolant extends Interpolant
- constructor · method · L18-L22 — constructor( parameterPositions, sampleValues, sampleSize, resultBuffer )
- interpolate_ · method · L24-L46 — interpolate_( i1, t0, t, t1 )
