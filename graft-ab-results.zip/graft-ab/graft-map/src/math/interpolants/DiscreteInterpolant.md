# src/math/interpolants/DiscreteInterpolant.js

- DiscreteInterpolant · class · L9-L31 — class DiscreteInterpolant extends Interpolant
- constructor · method · L19-L23 — constructor( parameterPositions, sampleValues, sampleSize, resultBuffer )
- interpolate_ · method · L25-L29 — interpolate_( i1 /*, t0, t, t1 */ )
