# src/math/interpolants/QuaternionLinearInterpolant.js

- QuaternionLinearInterpolant · class · L9-L45 — class QuaternionLinearInterpolant extends Interpolant
- constructor · method · L19-L23 — constructor( parameterPositions, sampleValues, sampleSize, resultBuffer )
- interpolate_ · method · L25-L43 — interpolate_( i1, t0, t, t1 )
