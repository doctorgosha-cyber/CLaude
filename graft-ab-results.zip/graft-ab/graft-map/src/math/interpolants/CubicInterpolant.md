# src/math/interpolants/CubicInterpolant.js

- CubicInterpolant · class · L13-L157 — class CubicInterpolant extends Interpolant
- constructor · method · L23-L39 — constructor( parameterPositions, sampleValues, sampleSize, resultBuffer )
- intervalChanged_ · method · L41-L118 — intervalChanged_( i1, t0, t1 )
- interpolate_ · method · L120-L155 — interpolate_( i1, t0, t, t1 )
