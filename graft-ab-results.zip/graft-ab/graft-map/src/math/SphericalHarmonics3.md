# src/math/SphericalHarmonics3.js

- SphericalHarmonics3 · class · L10-L339 — class SphericalHarmonics3
- constructor · method · L15-L39 — constructor()
- set · method · L48-L58 — set( coefficients )
- zero · method · L65-L75 — zero()
- getAt · method · L84-L109 — getAt( normal, target )
- getIrradianceAt · method · L119-L144 — getIrradianceAt( normal, target )
- add · method · L152-L162 — add( sh )
- addScaledSH · method · L172-L182 — addScaledSH( sh, s )
- scale · method · L190-L200 — scale( s )
- lerp · method · L210-L220 — lerp( sh, alpha )
- equals · method · L228-L242 — equals( sh )
- copy · method · L250-L254 — copy( sh )
- clone · method · L261-L265 — clone()
- fromArray · method · L274-L286 — fromArray( array, offset = 0 )
- toArray · method · L296-L308 — toArray( array = [], offset = 0 )
- getBasisAt · method · L316-L337 — static getBasisAt( normal, shBasis )
