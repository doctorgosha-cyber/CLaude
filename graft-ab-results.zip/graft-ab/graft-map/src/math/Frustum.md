# src/math/Frustum.js

- Frustum · class · L18-L282 — class Frustum
- constructor · method · L30-L39 — constructor( p0 = new Plane(), p1 = new Plane(), p2 = new Plane(), p3 = new Plane(), p4 = new Plane(), p5 = new Plane() )
- set · method · L52-L65 — set( p0, p1, p2, p3, p4, p5 )
- copy · method · L73-L85 — copy( frustum )
- setFromProjectionMatrix · method · L95-L136 — setFromProjectionMatrix( m, coordinateSystem = WebGLCoordinateSystem, reversedDepth = false )
- intersectsObject · method · L146-L166 — intersectsObject( object )
- intersectsSprite · method · L174-L185 — intersectsSprite( sprite )
- intersectsSphere · method · L193-L213 — intersectsSphere( sphere )
- intersectsBox · method · L221-L245 — intersectsBox( box )
- containsPoint · method · L253-L269 — containsPoint( point )
- clone · method · L276-L280 — clone()
