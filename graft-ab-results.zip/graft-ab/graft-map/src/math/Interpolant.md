# src/math/Interpolant.js

- Interpolant · class · L20-L318 — class Interpolant
- constructor · method · L30-L84 — constructor( parameterPositions, sampleValues, sampleSize, resultBuffer )
- evaluate · method · L92-L250 — evaluate( t )
- getSettings_ · method · L257-L261 — getSettings_()
- copySampleValue_ · method · L269-L286 — copySampleValue_( index )
- interpolate_ · method · L298-L303 — interpolate_( /* i1, t0, t, t1 */ )
- intervalChanged_ · method · L312-L316 — intervalChanged_( /* i1, t0, t1 */ )
