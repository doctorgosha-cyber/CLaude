# src/math/ColorManagement.js

- createColorManagement · function · L17-L195 — function createColorManagement()
- SRGBToLinear · function · L199-L203 — function SRGBToLinear( c )
- LinearToSRGB · function · L205-L209 — function LinearToSRGB( c )
