# src/math/Spherical.js

- Spherical · class · L7-L145 — class Spherical
- constructor · method · L16-L42 — constructor( radius = 1, phi = 0, theta = 0 )
- set · method · L52-L60 — set( radius, phi, theta )
- copy · method · L68-L76 — copy( other )
- makeSafe · method · L84-L91 — makeSafe()
- setFromVector3 · method · L100-L104 — setFromVector3( v )
- setFromCartesianCoords · method · L114-L132 — setFromCartesianCoords( x, y, z )
- clone · method · L139-L143 — clone()
