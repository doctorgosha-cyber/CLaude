# src/math/Matrix2.js

- Matrix2 · class · L27-L124 — class Matrix2
- constructor · method · L39-L66 — constructor( n11, n12, n21, n22 )
- identity · method · L73-L82 — identity()
- fromArray · method · L91-L101 — fromArray( array, offset = 0 )
- set · method · L113-L122 — set( n11, n12, n21, n22 )
