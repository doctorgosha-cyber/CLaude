# src/math/Line3.js

- Line3 · class · L16-L334 — class Line3
- constructor · method · L24-L40 — constructor( start = new Vector3(), end = new Vector3() )
- set · method · L49-L56 — set( start, end )
- copy · method · L64-L71 — copy( line )
- getCenter · method · L79-L83 — getCenter( target )
- delta · method · L91-L95 — delta( target )
- distanceSq · method · L102-L106 — distanceSq()
- distance · method · L113-L117 — distance()
- at · method · L126-L130 — at( t, target )
- closestPointToPointParameter · method · L139-L157 — closestPointToPointParameter( point, clampToLine )
- closestPointToPoint · method · L167-L173 — closestPointToPoint( point, clampToLine, target )
- distanceSqToLine3 · method · L183-L294 — distanceSqToLine3( line, c1 = _c1, c2 = _c2 )
- applyMatrix4 · method · L302-L309 — applyMatrix4( matrix )
- equals · method · L317-L321 — equals( line )
- clone · method · L328-L332 — clone()
