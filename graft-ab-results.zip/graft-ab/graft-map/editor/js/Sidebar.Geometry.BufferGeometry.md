# editor/js/Sidebar.Geometry.BufferGeometry.js

- SidebarGeometryBufferGeometry · function · L3-L113 — function SidebarGeometryBufferGeometry( editor )
- update · function · L11-L106 — function update( object )
