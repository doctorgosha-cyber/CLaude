# editor/js/Sidebar.Material.RangeValueProperty.js

- SidebarMaterialRangeValueProperty · function · L4-L61 — function SidebarMaterialRangeValueProperty( editor, property, name, isMin, range = [ - Infinity, Infinity ], precision = 2, step = 1, nudge = 0.01, unit = '' )
- onChange · function · L18-L29 — function onChange()
- update · function · L31-L52 — function update( currentObject, currentMaterialSlot = 0 )
