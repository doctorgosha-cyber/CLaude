# editor/js/Sidebar.Geometry.ExtrudeGeometry.js

- GeometryParametersPanel · function · L7-L194 — function GeometryParametersPanel( editor, object )
- updateBevelRow · function · L114-L132 — function updateBevelRow( enabled )
- refreshUI · function · L134-L149 — function refreshUI()
- update · function · L163-L181 — function update()
- toShape · function · L183-L190 — function toShape()
