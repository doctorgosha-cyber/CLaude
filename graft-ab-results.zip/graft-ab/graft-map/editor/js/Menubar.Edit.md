# editor/js/Menubar.Edit.js

- MenubarEdit · function · L10-L143 — function MenubarEdit( editor )
- onHistoryChanged · function · L52-L71 — function onHistoryChanged()
