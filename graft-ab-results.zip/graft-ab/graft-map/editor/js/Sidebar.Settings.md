# editor/js/Sidebar.Settings.js

- SidebarSettings · function · L6-L56 — function SidebarSettings( editor )
