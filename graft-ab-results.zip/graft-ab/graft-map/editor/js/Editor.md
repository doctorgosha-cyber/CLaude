# editor/js/Editor.js

- Editor · function · L15-L135 — function Editor()
- save · function · L754-L766 — function save( blob, filename )
- saveArrayBuffer · function · L768-L772 — function saveArrayBuffer( buffer, filename )
- saveString · function · L774-L778 — function saveString( text, filename )
- formatNumber · function · L780-L784 — function formatNumber( number )
