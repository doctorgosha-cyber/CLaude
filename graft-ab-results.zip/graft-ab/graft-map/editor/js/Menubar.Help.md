# editor/js/Menubar.Help.js

- MenubarHelp · function · L3-L71 — function MenubarHelp( editor )
