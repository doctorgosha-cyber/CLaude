# editor/js/Sidebar.Script.js

- SidebarScript · function · L7-L127 — function SidebarScript( editor )
- update · function · L40-L101 — function update()
