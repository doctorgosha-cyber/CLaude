# editor/js/Sidebar.Material.js

- SidebarMaterial · function · L16-L690 — function SidebarMaterial( editor )
- update · function · L455-L560 — function update()
- setRowVisibility · function · L564-L578 — function setRowVisibility()
- refreshUI · function · L580-L651 — function refreshUI()
