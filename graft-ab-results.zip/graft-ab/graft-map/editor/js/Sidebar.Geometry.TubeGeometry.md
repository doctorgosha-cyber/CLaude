# editor/js/Sidebar.Geometry.TubeGeometry.js

- GeometryParametersPanel · function · L8-L133 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L88-L103 — function refreshUI()
- update · function · L117-L129 — function update()
