# editor/js/Sidebar.Project.Renderer.js

- SidebarProjectRenderer · function · L6-L142 — function SidebarProjectRenderer( editor )
- updateShadows · function · L46-L53 — function updateShadows()
- updateToneMapping · function · L81-L89 — function updateToneMapping()
- createRenderer · function · L93-L104 — function createRenderer()
