# editor/js/Sidebar.Geometry.ShapeGeometry.js

- GeometryParametersPanel · function · L7-L74 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L33-L39 — function refreshUI()
- changeShape · function · L53-L60 — function changeShape()
- toExtrude · function · L62-L70 — function toExtrude()
