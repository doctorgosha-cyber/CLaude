# editor/js/Menubar.Add.js

- MenubarAdd · function · L7-L508 — function MenubarAdd( editor )
