# editor/js/Sidebar.Object.Animation.js

- SidebarObjectAnimation · function · L3-L100 — function SidebarObjectAnimation( editor )
- getButtonText · function · L9-L15 — function getButtonText( action )
- Animation · function · L17-L38 — function Animation( animation, object )
