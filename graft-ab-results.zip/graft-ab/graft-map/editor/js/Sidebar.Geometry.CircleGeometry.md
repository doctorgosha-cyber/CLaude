# editor/js/Sidebar.Geometry.CircleGeometry.js

- GeometryParametersPanel · function · L7-L95 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L59-L68 — function refreshUI()
- update · function · L82-L91 — function update()
