# editor/js/Sidebar.Project.Image.js

- SidebarProjectImage · function · L7-L223 — function SidebarProjectImage( editor )
- refreshShadingRow · function · L42-L46 — function refreshShadingRow()
- animate · function · L184-L208 — function animate()
