# editor/js/Menubar.View.js

- MenubarView · function · L3-L191 — function MenubarView( editor )
