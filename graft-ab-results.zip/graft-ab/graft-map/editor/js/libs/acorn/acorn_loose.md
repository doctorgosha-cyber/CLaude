# editor/js/libs/acorn/acorn_loose.js

- s · function · L1-L1 — function s(o,u)
- _interopRequireWildcard · function · L4-L4 — _interopRequireWildcard = function (obj)
- parse_dammit · function · L59-L63 — function parse_dammit(input, options)
- isDummy · function · L650-L652 — function isDummy(node)
- LooseParser · function · L736-L750 — function LooseParser(input, options)
- isSpace · function · L1202-L1204 — function isSpace(ch)
