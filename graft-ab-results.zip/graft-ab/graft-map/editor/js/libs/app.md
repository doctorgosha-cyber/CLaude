# editor/js/libs/app.js

- dispatch · function · L136-L144 — function dispatch( array, event )
- animate · function · L148-L166 — function animate()
- onKeyDown · function · L217-L221 — function onKeyDown( event )
- onKeyUp · function · L223-L227 — function onKeyUp( event )
- onPointerDown · function · L229-L233 — function onPointerDown( event )
- onPointerUp · function · L235-L239 — function onPointerUp( event )
- onPointerMove · function · L241-L245 — function onPointerMove( event )
