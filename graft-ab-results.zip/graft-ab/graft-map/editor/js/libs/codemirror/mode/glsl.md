# editor/js/libs/codemirror/mode/glsl.js

- tokenBase · function · L52-L102 — function tokenBase(stream, state)
- tokenString · function · L104-L115 — function tokenString(quote)
- tokenComment · function · L117-L127 — function tokenComment(stream, state)
- Context · function · L129-L135 — function Context(indented, column, type, align, prev)
- pushContext · function · L136-L138 — function pushContext(state, col, type)
- popContext · function · L139-L144 — function popContext(state)
- words · function · L199-L203 — function words(str)
- cppHook · function · L217-L221 — function cppHook(stream, state)
