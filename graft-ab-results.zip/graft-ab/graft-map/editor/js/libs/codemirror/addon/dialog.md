# editor/js/libs/codemirror/addon/dialog.js

- dialogDiv · function · L14-L30 — function dialogDiv(cm, template, bottom)
- closeNotification · function · L32-L36 — function closeNotification(cm, newVal)
- close · function · L45-L57 — function close(newVal)
- close · function · L106-L112 — function close()
- close · function · L145-L151 — function close()
