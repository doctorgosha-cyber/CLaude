# editor/js/libs/codemirror/addon/show-hint.js

- Completion · function · L55-L68 — function Completion(cm, options)
- parseOptions · function · L159-L169 — function parseOptions(cm, pos, options)
- getText · function · L171-L174 — function getText(completion)
- buildKeyMap · function · L176-L217 — function buildKeyMap(completion, handle)
- addBinding · function · L198-L208 — function addBinding(key, val)
- getHintElement · function · L219-L224 — function getHintElement(hintsElement, el)
- Widget · function · L226-L369 — function Widget(completion, data)
- applicableHelpers · function · L443-L449 — function applicableHelpers(cm, helpers)
- fetchHints · function · L451-L459 — function fetchHints(hint, cm, options, callback)
- resolveAutoHints · function · L461-L485 — function resolveAutoHints(cm, pos)
- resolved · function · L464-L474 — resolved = function(cm, callback, options)
- run · function · L466-L472 — function run(i)
