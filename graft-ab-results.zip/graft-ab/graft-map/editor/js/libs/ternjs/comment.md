# editor/js/libs/ternjs/comment.js

- isSpace · function · L8-L10 — function isSpace(ch)
- onOwnLine · function · L12-L19 — function onOwnLine(text, pos)
