# editor/js/libs/ternjs/polyfill.js

- ctor · function · L11-L11 — function ctor()
- R · function · L65-L67 — function R(b)
