# editor/js/libs/ternjs/signal.js

- on · function · L8-L11 — function on(type, f)
- off · function · L12-L16 — function off(type, f)
- signal · function · L17-L20 — function signal(type, a1, a2, a3, a4)
