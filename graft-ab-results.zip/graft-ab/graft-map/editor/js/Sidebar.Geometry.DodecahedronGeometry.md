# editor/js/Sidebar.Geometry.DodecahedronGeometry.js

- GeometryParametersPanel · function · L7-L71 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L39-L46 — function refreshUI()
- update · function · L60-L67 — function update()
