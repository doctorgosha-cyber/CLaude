# editor/js/Resizer.js

- Resizer · function · L3-L56 — function Resizer( editor )
- onPointerDown · function · L10-L17 — function onPointerDown( event )
- onPointerUp · function · L19-L26 — function onPointerUp( event )
- onPointerMove · function · L28-L50 — function onPointerMove( event )
