# editor/js/Sidebar.Settings.History.js

- SidebarSettingsHistory · function · L5-L144 — function SidebarSettingsHistory( editor )
- refreshUI · function · L77-L124 — refreshUI = function ()
- buildOption · function · L81-L88 — function buildOption( object )
