# editor/js/Command.js

- Command · class · L1-L38 — class Command
- constructor · method · L8-L17 — constructor( editor )
- toJSON · method · L19-L27 — toJSON()
- fromJSON · method · L29-L36 — fromJSON( json )
