# editor/js/Sidebar.Geometry.LatheGeometry.js

- GeometryParametersPanel · function · L8-L96 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L60-L69 — function refreshUI()
- update · function · L83-L92 — function update()
