# editor/js/Sidebar.Project.Video.js

- SidebarProjectVideo · function · L5-L227 — function SidebarProjectVideo( editor )
- toDiv2 · function · L19-L25 — function toDiv2()
- formatFileSize · function · L229-L240 — function formatFileSize( sizeB, K = 1024 )
