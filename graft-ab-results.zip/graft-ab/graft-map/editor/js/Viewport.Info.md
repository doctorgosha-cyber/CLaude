# editor/js/Viewport.Info.js

- ViewportInfo · function · L3-L142 — function ViewportInfo( editor )
- update · function · L46-L108 — function update()
- updateFrametime · function · L110-L114 — function updateFrametime( frametime )
