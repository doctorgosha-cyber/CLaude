# editor/js/Sidebar.Material.BooleanProperty.js

- SidebarMaterialBooleanProperty · function · L4-L58 — function SidebarMaterialBooleanProperty( editor, property, name )
- onChange · function · L18-L26 — function onChange()
- update · function · L28-L49 — function update( currentObject, currentMaterialSlot = 0 )
