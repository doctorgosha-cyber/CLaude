# editor/js/Viewport.Pathtracer.js

- ViewportPathtracer · function · L3-L89 — function ViewportPathtracer( renderer )
- init · function · L7-L18 — function init( scene, camera )
- setSize · function · L20-L27 — function setSize( /* width, height */ )
- setBackground · function · L29-L36 — function setBackground( /* background, blurriness */ )
- updateMaterials · function · L38-L44 — function updateMaterials()
- setEnvironment · function · L46-L52 — function setEnvironment( /* environment */ )
- update · function · L54-L60 — function update()
- reset · function · L62-L68 — function reset()
- getSamples · function · L70-L76 — function getSamples()
