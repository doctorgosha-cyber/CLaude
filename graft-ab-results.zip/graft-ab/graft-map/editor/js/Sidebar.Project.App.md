# editor/js/Sidebar.Project.App.js

- SidebarProjectApp · function · L7-L168 — function SidebarProjectApp( editor )
