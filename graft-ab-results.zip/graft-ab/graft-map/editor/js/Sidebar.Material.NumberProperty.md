# editor/js/Sidebar.Material.NumberProperty.js

- SidebarMaterialNumberProperty · function · L4-L58 — function SidebarMaterialNumberProperty( editor, property, name, range = [ - Infinity, Infinity ], precision = 2 )
- onChange · function · L18-L26 — function onChange()
- update · function · L28-L49 — function update( currentObject, currentMaterialSlot = 0 )
