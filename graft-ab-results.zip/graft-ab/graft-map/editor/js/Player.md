# editor/js/Player.js

- Player · function · L4-L51 — function Player( editor )
