# editor/js/Storage.js

- Storage · function · L1-L96 — function Storage()
