# editor/js/Sidebar.Material.MapProperty.js

- SidebarMaterialMapProperty · function · L10-L247 — function SidebarMaterialMapProperty( editor, property, name )
- onChange · function · L91-L111 — function onChange()
- onMapChange · function · L113-L130 — function onMapChange( texture )
- onIntensityChange · function · L132-L140 — function onIntensityChange()
- onScaleChange · function · L142-L150 — function onScaleChange()
- onScaleXYChange · function · L152-L162 — function onScaleXYChange()
- onRangeChange · function · L164-L174 — function onRangeChange()
- update · function · L176-L231 — function update( currentObject, currentMaterialSlot = 0 )
