# editor/js/commands/SetUuidCommand.js

- SetUuidCommand · class · L3-L68 — class SetUuidCommand extends Command
- constructor · method · L11-L23 — constructor( editor, object = null, newUuid = null )
- execute · method · L25-L31 — execute()
- undo · method · L33-L39 — undo()
- toJSON · method · L41-L50 — toJSON()
- fromJSON · method · L52-L66 — fromJSON( json )
