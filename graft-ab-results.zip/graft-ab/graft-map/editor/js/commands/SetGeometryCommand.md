# editor/js/commands/SetGeometryCommand.js

- SetGeometryCommand · class · L4-L84 — class SetGeometryCommand extends Command
- constructor · method · L12-L24 — constructor( editor, object = null, newGeometry = null )
- execute · method · L26-L35 — execute()
- undo · method · L37-L46 — undo()
- update · method · L48-L52 — update( cmd )
- toJSON · method · L54-L64 — toJSON()
- fromJSON · method · L66-L82 — fromJSON( json )
- parseGeometry · function · L75-L80 — function parseGeometry( data )
