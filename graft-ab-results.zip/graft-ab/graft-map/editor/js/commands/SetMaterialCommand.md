# editor/js/commands/SetMaterialCommand.js

- SetMaterialCommand · class · L4-L78 — class SetMaterialCommand extends Command
- constructor · method · L13-L26 — constructor( editor, object = null, newMaterial = null, materialSlot = - 1 )
- execute · method · L28-L34 — execute()
- undo · method · L36-L42 — undo()
- toJSON · method · L44-L55 — toJSON()
- fromJSON · method · L57-L76 — fromJSON( json )
- parseMaterial · function · L66-L74 — function parseMaterial( json )
