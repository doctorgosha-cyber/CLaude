# editor/js/commands/SetMaterialColorCommand.js

- SetMaterialColorCommand · class · L3-L85 — class SetMaterialColorCommand extends Command
- constructor · method · L13-L31 — constructor( editor, object = null, attributeName = '', newValue = null, materialSlot = - 1 )
- execute · method · L33-L41 — execute()
- undo · method · L43-L51 — undo()
- update · method · L53-L57 — update( cmd )
- toJSON · method · L59-L71 — toJSON()
- fromJSON · method · L73-L83 — fromJSON( json )
