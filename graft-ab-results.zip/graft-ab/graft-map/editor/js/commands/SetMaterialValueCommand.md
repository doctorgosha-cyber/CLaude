# editor/js/commands/SetMaterialValueCommand.js

- SetMaterialValueCommand · class · L3-L89 — class SetMaterialValueCommand extends Command
- constructor · method · L13-L31 — constructor( editor, object = null, attributeName = '', newValue = null, materialSlot = - 1 )
- execute · method · L33-L43 — execute()
- undo · method · L45-L55 — undo()
- update · method · L57-L61 — update( cmd )
- toJSON · method · L63-L75 — toJSON()
- fromJSON · method · L77-L87 — fromJSON( json )
