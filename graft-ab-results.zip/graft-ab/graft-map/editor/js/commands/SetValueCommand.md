# editor/js/commands/SetValueCommand.js

- SetValueCommand · class · L3-L73 — class SetValueCommand extends Command
- constructor · method · L12-L25 — constructor( editor, object = null, attributeName = '', newValue = null )
- execute · method · L27-L33 — execute()
- undo · method · L35-L41 — undo()
- update · method · L43-L47 — update( cmd )
- toJSON · method · L49-L60 — toJSON()
- fromJSON · method · L62-L71 — fromJSON( json )
