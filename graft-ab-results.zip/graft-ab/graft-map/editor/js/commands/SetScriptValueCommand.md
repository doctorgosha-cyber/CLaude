# editor/js/commands/SetScriptValueCommand.js

- SetScriptValueCommand · class · L3-L78 — class SetScriptValueCommand extends Command
- constructor · method · L13-L28 — constructor( editor, object = null, script = '', attributeName = '', newValue = null )
- execute · method · L30-L36 — execute()
- undo · method · L38-L44 — undo()
- update · method · L46-L50 — update( cmd )
- toJSON · method · L52-L64 — toJSON()
- fromJSON · method · L66-L76 — fromJSON( json )
