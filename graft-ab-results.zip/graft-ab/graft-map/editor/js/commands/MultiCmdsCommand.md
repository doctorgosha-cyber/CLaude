# editor/js/commands/MultiCmdsCommand.js

- MultiCmdsCommand · class · L3-L83 — class MultiCmdsCommand extends Command
- constructor · method · L10-L19 — constructor( editor, cmdArray = [] )
- execute · method · L21-L34 — execute()
- undo · method · L36-L49 — undo()
- toJSON · method · L51-L66 — toJSON()
- fromJSON · method · L68-L81 — fromJSON( json )
