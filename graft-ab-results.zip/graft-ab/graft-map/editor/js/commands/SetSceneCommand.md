# editor/js/commands/SetSceneCommand.js

- SetSceneCommand · class · L6-L101 — class SetSceneCommand extends Command
- constructor · method · L13-L37 — constructor( editor, scene = null )
- execute · method · L39-L52 — execute()
- undo · method · L54-L67 — undo()
- toJSON · method · L69-L84 — toJSON()
- fromJSON · method · L86-L99 — fromJSON( json )
