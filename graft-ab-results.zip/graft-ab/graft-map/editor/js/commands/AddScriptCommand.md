# editor/js/commands/AddScriptCommand.js

- AddScriptCommand · class · L3-L73 — class AddScriptCommand extends Command
- constructor · method · L11-L21 — constructor( editor, object = null, script = '' )
- execute · method · L23-L35 — execute()
- undo · method · L37-L51 — undo()
- toJSON · method · L53-L62 — toJSON()
- fromJSON · method · L64-L71 — fromJSON( json )
