# editor/js/commands/SetMaterialMapCommand.js

- SetMaterialMapCommand · class · L4-L142 — class SetMaterialMapCommand extends Command
- constructor · method · L14-L31 — constructor( editor, object = null, mapName = '', newMap = null, materialSlot = - 1 )
- execute · method · L33-L44 — execute()
- undo · method · L46-L55 — undo()
- toJSON · method · L57-L111 — toJSON()
- serializeMap · function · L71-L89 — function serializeMap( map )
- extractFromCache · function · L96-L109 — function extractFromCache( cache )
- fromJSON · method · L113-L140 — fromJSON( json )
- parseTexture · function · L123-L138 — function parseTexture( json )
