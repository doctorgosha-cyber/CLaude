# editor/js/commands/SetShadowValueCommand.js

- SetShadowValueCommand · class · L3-L71 — class SetShadowValueCommand extends Command
- constructor · method · L12-L25 — constructor( editor, object = null, attributeName = '', newValue = null )
- execute · method · L27-L32 — execute()
- undo · method · L34-L39 — undo()
- update · method · L41-L45 — update( cmd )
- toJSON · method · L47-L58 — toJSON()
- fromJSON · method · L60-L69 — fromJSON( json )
