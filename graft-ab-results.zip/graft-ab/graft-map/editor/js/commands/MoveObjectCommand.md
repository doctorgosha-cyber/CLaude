# editor/js/commands/MoveObjectCommand.js

- MoveObjectCommand · class · L3-L115 — class MoveObjectCommand extends Command
- constructor · method · L12-L42 — constructor( editor, object = null, newParent = null, newBefore = null )
- execute · method · L44-L58 — execute()
- undo · method · L60-L74 — undo()
- toJSON · method · L76-L88 — toJSON()
- fromJSON · method · L90-L113 — fromJSON( json )
