# editor/js/commands/AddObjectCommand.js

- AddObjectCommand · class · L4-L66 — class AddObjectCommand extends Command
- constructor · method · L11-L25 — constructor( editor, object = null )
- execute · method · L27-L32 — execute()
- undo · method · L34-L39 — undo()
- toJSON · method · L41-L49 — toJSON()
- fromJSON · method · L51-L64 — fromJSON( json )
