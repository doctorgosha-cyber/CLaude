# editor/js/commands/RemoveScriptCommand.js

- RemoveScriptCommand · class · L3-L79 — class RemoveScriptCommand extends Command
- constructor · method · L11-L27 — constructor( editor, object = null, script = '' )
- execute · method · L29-L41 — execute()
- undo · method · L43-L55 — undo()
- toJSON · method · L57-L67 — toJSON()
- fromJSON · method · L69-L77 — fromJSON( json )
