# editor/js/commands/SetMaterialVectorCommand.js

- SetMaterialVectorCommand · class · L3-L86 — class SetMaterialVectorCommand extends Command
- constructor · method · L14-L32 — constructor( editor, object = null, attributeName = '', newValue = null, materialSlot = - 1 )
- execute · method · L34-L42 — execute()
- undo · method · L44-L52 — undo()
- update · method · L54-L58 — update( cmd )
- toJSON · method · L60-L72 — toJSON()
- fromJSON · method · L74-L84 — fromJSON( json )
