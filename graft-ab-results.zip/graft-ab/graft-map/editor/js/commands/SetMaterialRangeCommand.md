# editor/js/commands/SetMaterialRangeCommand.js

- SetMaterialRangeCommand · class · L3-L90 — class SetMaterialRangeCommand extends Command
- constructor · method · L14-L32 — constructor( editor, object = null, attributeName = '', newMinValue = - Infinity, newMaxValue = Infinity, materialSlot = - 1 )
- execute · method · L34-L44 — execute()
- undo · method · L46-L56 — undo()
- update · method · L58-L62 — update( cmd )
- toJSON · method · L64-L76 — toJSON()
- fromJSON · method · L78-L88 — fromJSON( json )
