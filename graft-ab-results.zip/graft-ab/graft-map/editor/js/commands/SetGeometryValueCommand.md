# editor/js/commands/SetGeometryValueCommand.js

- SetGeometryValueCommand · class · L3-L68 — class SetGeometryValueCommand extends Command
- constructor · method · L12-L24 — constructor( editor, object = null, attributeName = '', newValue = null )
- execute · method · L26-L33 — execute()
- undo · method · L35-L42 — undo()
- toJSON · method · L44-L55 — toJSON()
- fromJSON · method · L57-L66 — fromJSON( json )
