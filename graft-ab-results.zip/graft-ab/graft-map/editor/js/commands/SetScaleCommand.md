# editor/js/commands/SetScaleCommand.js

- SetScaleCommand · class · L4-L82 — class SetScaleCommand extends Command
- constructor · method · L13-L36 — constructor( editor, object = null, newScale = null, optionalOldScale = null )
- execute · method · L38-L44 — execute()
- undo · method · L46-L52 — undo()
- update · method · L54-L58 — update( command )
- toJSON · method · L60-L70 — toJSON()
- fromJSON · method · L72-L80 — fromJSON( json )
