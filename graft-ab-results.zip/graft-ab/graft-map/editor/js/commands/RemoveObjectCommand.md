# editor/js/commands/RemoveObjectCommand.js

- RemoveObjectCommand · class · L5-L86 — class RemoveObjectCommand extends Command
- constructor · method · L12-L34 — constructor( editor, object = null )
- execute · method · L36-L41 — execute()
- undo · method · L43-L48 — undo()
- toJSON · method · L50-L60 — toJSON()
- fromJSON · method · L62-L84 — fromJSON( json )
