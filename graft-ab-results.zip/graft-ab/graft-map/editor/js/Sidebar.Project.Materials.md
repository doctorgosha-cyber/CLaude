# editor/js/Sidebar.Project.Materials.js

- SidebarProjectMaterials · function · L5-L80 — function SidebarProjectMaterials( editor )
- refreshMaterialBrowserUI · function · L57-L61 — function refreshMaterialBrowserUI()
