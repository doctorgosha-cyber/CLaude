# editor/js/Loader.js

- Loader · function · L11-L1008 — function Loader( editor )
- handleJSON · function · L802-L870 — function handleJSON( data )
- handleZIP · function · L872-L982 — async function handleZIP( contents )
- createGLTFLoader · function · L984-L1006 — async function createGLTFLoader( manager )
