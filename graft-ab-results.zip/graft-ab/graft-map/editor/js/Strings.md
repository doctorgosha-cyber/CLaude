# editor/js/Strings.js

- Strings · function · L1-L2431 — function Strings( config )
