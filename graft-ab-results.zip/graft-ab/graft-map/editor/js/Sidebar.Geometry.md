# editor/js/Sidebar.Geometry.js

- SidebarGeometry · function · L12-L330 — function SidebarGeometry( editor )
- build · function · L249-L316 — async function build()
