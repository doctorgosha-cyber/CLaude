# editor/js/Sidebar.Geometry.TorusGeometry.js

- GeometryParametersPanel · function · L7-L107 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L69-L79 — function refreshUI()
- update · function · L93-L103 — function update()
