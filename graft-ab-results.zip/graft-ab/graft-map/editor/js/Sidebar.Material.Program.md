# editor/js/Sidebar.Material.Program.js

- SidebarMaterialProgram · function · L3-L71 — function SidebarMaterialProgram( editor, property )
- update · function · L42-L62 — function update( currentObject, currentMaterialSlot = 0 )
