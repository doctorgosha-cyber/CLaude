# editor/js/Menubar.Status.js

- MenubarStatus · function · L6-L49 — function MenubarStatus( editor )
