# editor/js/Viewport.XR.js

- XR · class · L8-L220 — class XR
- constructor · method · L10-L218 — constructor( editor, controls )
- onSessionStarted · function · L21-L158 — onSessionStarted = async ( session )
- onSelect · function · L40-L76 — function onSelect( event )
- onControllerEvent · function · L78-L103 — function onControllerEvent( event )
- onSessionEnded · function · L160-L177 — onSessionEnded = async ()
