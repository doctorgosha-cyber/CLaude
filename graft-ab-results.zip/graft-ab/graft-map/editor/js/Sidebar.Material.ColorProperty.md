# editor/js/Sidebar.Material.ColorProperty.js

- SidebarMaterialColorProperty · function · L5-L85 — function SidebarMaterialColorProperty( editor, property, name )
- onChange · function · L28-L46 — function onChange()
- update · function · L48-L76 — function update( currentObject, currentMaterialSlot = 0 )
