# editor/js/Script.js

- Script · function · L6-L501 — function Script( editor )
- validate · function · L144-L289 — validate = function ( string )
- setTitle · function · L363-L396 — function setTitle( object, script )
