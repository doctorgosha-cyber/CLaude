# editor/js/Sidebar.js

- Sidebar · function · L8-L39 — function Sidebar( editor )
