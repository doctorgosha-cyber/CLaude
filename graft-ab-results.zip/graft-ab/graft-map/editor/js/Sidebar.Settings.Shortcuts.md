# editor/js/Sidebar.Settings.Shortcuts.js

- SidebarSettingsShortcuts · function · L5-L173 — function SidebarSettingsShortcuts( editor )
- isValidKeyBinding · function · L11-L15 — function isValidKeyBinding( key )
- createShortcutInput · function · L28-L90 — function createShortcutInput( name )
