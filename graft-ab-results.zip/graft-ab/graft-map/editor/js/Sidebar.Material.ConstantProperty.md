# editor/js/Sidebar.Material.ConstantProperty.js

- SidebarMaterialConstantProperty · function · L4-L60 — function SidebarMaterialConstantProperty( editor, property, name, options )
- onChange · function · L18-L28 — function onChange()
- update · function · L30-L51 — function update( currentObject, currentMaterialSlot = 0 )
