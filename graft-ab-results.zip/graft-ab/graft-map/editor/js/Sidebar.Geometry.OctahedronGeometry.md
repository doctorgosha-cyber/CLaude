# editor/js/Sidebar.Geometry.OctahedronGeometry.js

- GeometryParametersPanel · function · L7-L72 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L40-L47 — function refreshUI()
- update · function · L61-L68 — function update()
