# editor/js/Menubar.File.js

- MenubarFile · function · L3-L464 — function MenubarFile( editor )
- onEditorCleared · function · L123-L129 — async function onEditorCleared()
- getAnimations · function · L448-L460 — function getAnimations( scene )
