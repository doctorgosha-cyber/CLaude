# editor/js/Sidebar.Geometry.SphereGeometry.js

- GeometryParametersPanel · function · L7-L131 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L89-L101 — function refreshUI()
- update · function · L115-L127 — function update()
