# editor/js/Selector.js

- Selector · class · L6-L100 — class Selector
- constructor · method · L8-L43 — constructor( editor )
- getIntersects · method · L45-L63 — getIntersects( raycaster )
- getPointerIntersects · method · L65-L73 — getPointerIntersects( point, camera )
- select · method · L75-L92 — select( object )
- deselect · method · L94-L98 — deselect()
