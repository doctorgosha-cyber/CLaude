# editor/js/Config.js

- Config · function · L1-L79 — function Config()
