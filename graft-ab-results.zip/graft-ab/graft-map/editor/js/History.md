# editor/js/History.js

- History · class · L3-L319 — class History
- constructor · method · L5-L32 — constructor( editor )
- execute · method · L34-L85 — execute( cmd, optionalName )
- undo · method · L87-L120 — undo()
- redo · method · L122-L155 — redo()
- toJSON · method · L157-L195 — toJSON()
- fromJSON · method · L197-L228 — fromJSON( json )
- clear · method · L230-L238 — clear()
- goToState · method · L240-L283 — goToState( id )
- enableSerialization · method · L285-L317 — enableSerialization( id )
