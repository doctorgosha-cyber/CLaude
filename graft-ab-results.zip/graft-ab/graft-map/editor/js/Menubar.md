# editor/js/Menubar.js

- Menubar · function · L10-L25 — function Menubar( editor )
