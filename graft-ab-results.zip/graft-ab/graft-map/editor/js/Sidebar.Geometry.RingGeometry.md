# editor/js/Sidebar.Geometry.RingGeometry.js

- GeometryParametersPanel · function · L7-L119 — function GeometryParametersPanel( editor, object )
- refreshUI · function · L79-L90 — function refreshUI()
- update · function · L104-L115 — function update()
