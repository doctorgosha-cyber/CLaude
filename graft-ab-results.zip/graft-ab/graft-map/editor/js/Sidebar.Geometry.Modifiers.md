# editor/js/Sidebar.Geometry.Modifiers.js

- SidebarGeometryModifiers · function · L6-L71 — function SidebarGeometryModifiers( editor, object )
