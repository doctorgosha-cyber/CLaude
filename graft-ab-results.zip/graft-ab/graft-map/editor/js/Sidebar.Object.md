# editor/js/Sidebar.Object.js

- SidebarObject · function · L16-L896 — function SidebarObject( editor )
- update · function · L436-L638 — function update()
- updateRows · function · L640-L696 — function updateRows( object )
- updateTransformRows · function · L698-L712 — function updateTransformRows( object )
- updateUI · function · L749-L892 — function updateUI( object )
