# editor/js/Sidebar.Properties.js

- SidebarProperties · function · L8-L71 — function SidebarProperties( editor )
- getTabByTabId · function · L21-L29 — function getTabByTabId( tabs, tabId )
- toggleTabs · function · L35-L63 — function toggleTabs( object )
