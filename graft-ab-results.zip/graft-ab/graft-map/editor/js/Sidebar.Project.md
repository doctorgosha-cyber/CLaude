# editor/js/Sidebar.Project.js

- SidebarProject · function · L9-L29 — function SidebarProject( editor )
